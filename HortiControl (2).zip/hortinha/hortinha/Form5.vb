﻿Public Class Form5
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
        CarregarProdutosNoFlowPanel()

    End Sub
    Private Sub CarregarProdutosNoFlowPanel(Optional categoria As String = "")
        flowPanelProdutos.Controls.Clear()

        Dim sql As String
        If String.IsNullOrEmpty(categoria) Then
            sql = $"SELECT * FROM produtos ORDER BY nome_produto"
        Else
            sql = $"SELECT * FROM produtos WHERE categoria = '{categoria}' ORDER BY nome_produto"
        End If

        Dim rs As ADODB.Recordset = db.Execute(sql)
        While Not rs.EOF
            Dim cardProduto As Panel = CriarCardProduto(rs)
            flowPanelProdutos.Controls.Add(cardProduto)
            rs.MoveNext()
        End While

        If Not rs Is Nothing Then
            If rs.State = 1 Then
                rs.Close()
            End If
        End If
    End Sub

    Private Function CriarCardProduto(rs As ADODB.Recordset) As Panel
        Dim card As New Panel()
        card.Size = New Size(280, 140)
        card.BackColor = Color.White
        card.BorderStyle = BorderStyle.FixedSingle
        card.Margin = New Padding(10)
        Dim produtoId As Integer = Convert.ToInt32(rs.Fields("id_produto").Value)
        card.Tag = produtoId

        ' Extrair dados do Recordset (ADO clássico)
        Dim nome As String = rs.Fields("nome_produto").Value.ToString()
        Dim categoria As String = rs.Fields("categoria").Value.ToString()
        Dim quantidade As Integer = Convert.ToInt32(rs.Fields("quantidade_estoque").Value)
        Dim preco As Decimal = Convert.ToDecimal(rs.Fields("preco").Value)
        Dim dataVencimento As Date = Convert.ToDateTime(rs.Fields("data_vencimento").Value)
        Dim unidade As String = rs.Fields("unidade").Value.ToString()
        Dim statusProduto As String = rs.Fields("status_produto").Value.ToString()
        Dim diasRestantes As Integer = CalcularDiasRestantes(dataVencimento)

        ' Determinar status baseado no status_produto do banco
        Dim status As String
        Dim corStatus As Color
        Select Case statusProduto.ToLower()
            Case "publicado"
                If quantidade = 0 Then
                    status = "Sem Estoque"
                    corStatus = Color.Red
                ElseIf quantidade <= 10 Then
                    status = "Baixo"
                    corStatus = Color.Orange
                Else
                    status = "Normal"
                    corStatus = Color.Green
                End If
            Case "sem_estoque"
                status = "Sem Estoque"
                corStatus = Color.Red
            Case "indisponivel"
                status = "Indisponível"
                corStatus = Color.Red
            Case Else
                status = statusProduto
                corStatus = Color.Gray
        End Select

        ' ID do produto (canto superior esquerdo)
        Dim lblId As New Label()
        lblId.Text = $"ID: {produtoId}"
        lblId.Font = New Font("Arial", 8, FontStyle.Bold)
        lblId.Location = New Point(10, 10)
        lblId.Size = New Size(50, 15)
        lblId.ForeColor = Color.DarkBlue
        card.Controls.Add(lblId)

        ' Nome do produto (abaixo do ID)
        Dim lblNome As New Label()
        lblNome.Text = nome
        lblNome.Font = New Font("Arial", 12, FontStyle.Bold)
        lblNome.Location = New Point(10, 25)
        lblNome.Size = New Size(200, 20)
        card.Controls.Add(lblNome)

        ' Categoria (abaixo do nome)
        Dim lblCategoria As New Label()
        lblCategoria.Text = categoria
        lblCategoria.Font = New Font("Arial", 9, FontStyle.Italic)
        lblCategoria.Location = New Point(10, 45)
        lblCategoria.Size = New Size(150, 15)
        lblCategoria.ForeColor = Color.Gray
        card.Controls.Add(lblCategoria)

        ' Quantidade e unidade
        Dim lblQuantidade As New Label()
        lblQuantidade.Text = $"{quantidade} {unidade}"
        lblQuantidade.Font = New Font("Arial", 10)
        lblQuantidade.Location = New Point(10, 65)
        lblQuantidade.Size = New Size(120, 20)
        card.Controls.Add(lblQuantidade)

        ' Preço
        Dim lblPreco As New Label()
        lblPreco.Text = $"R$ {preco.ToString("F2")}"
        lblPreco.Font = New Font("Arial", 11, FontStyle.Bold)
        lblPreco.Location = New Point(10, 90)
        lblPreco.Size = New Size(100, 20)
        lblPreco.ForeColor = Color.DarkGreen
        card.Controls.Add(lblPreco)

        ' Status (alinhado à direita, em cima)
        Dim lblStatus As New Label()
        lblStatus.Text = status
        lblStatus.Location = New Point(130, 65)
        lblStatus.Size = New Size(90, 20)
        lblStatus.ForeColor = corStatus
        lblStatus.Font = New Font("Arial", 9, FontStyle.Bold)
        lblStatus.TextAlign = ContentAlignment.MiddleRight
        card.Controls.Add(lblStatus)

        ' Validade (alinhado à direita, embaixo do status)
        Dim lblValidade As New Label()
        Dim textoValidade As String = If(diasRestantes = 0, "0d", $"{diasRestantes}d")
        lblValidade.Text = textoValidade
        lblValidade.Location = New Point(130, 90)
        lblValidade.Size = New Size(90, 20)
        lblValidade.Font = New Font("Arial", 9)
        lblValidade.TextAlign = ContentAlignment.MiddleRight

        ' Cor da validade
        If diasRestantes = 0 Then
            lblValidade.ForeColor = Color.Red
        ElseIf diasRestantes <= 2 Then
            lblValidade.ForeColor = Color.Orange
        Else
            lblValidade.ForeColor = Color.Green
        End If
        card.Controls.Add(lblValidade)

        ' Botão Editar (✏️)
        Dim btnEditar As New Button()
        btnEditar.Text = "✏️"
        btnEditar.Size = New Size(30, 30)
        btnEditar.Location = New Point(230, 10)
        btnEditar.BackColor = Color.LightGreen
        btnEditar.FlatStyle = FlatStyle.Flat
        btnEditar.Font = New Font("Arial", 12, FontStyle.Bold)

        ' Handler para abrir Form3 com as informações do produto
        AddHandler btnEditar.Click, Sub(s, e)
                                        Dim btn As Button = DirectCast(s, Button)
                                        Dim cardParent As Panel = DirectCast(btn.Parent, Panel)
                                        Dim idProduto As Integer = CInt(cardParent.Tag)
                                        AbrirForm3ComProduto(idProduto)
                                    End Sub
        card.Controls.Add(btnEditar)

        Dim btnExcluir As New Button()
        btnExcluir.Text = "🗑️"
        btnExcluir.Size = New Size(30, 30)
        btnExcluir.Location = New Point(230, 50)
        btnExcluir.BackColor = Color.LightCoral
        btnExcluir.FlatStyle = FlatStyle.Flat
        btnExcluir.Font = New Font("Arial", 10)

        ' Handler para excluir produto
        AddHandler btnExcluir.Click, Sub(s, e)
                                         Dim btn As Button = DirectCast(s, Button)
                                         Dim cardParent As Panel = DirectCast(btn.Parent, Panel)
                                         Dim idProduto As Integer = CInt(cardParent.Tag)
                                         ExcluirProduto(idProduto, cardParent)
                                     End Sub
        card.Controls.Add(btnExcluir)

        Return card
    End Function

    Private Sub AbrirForm3ComProduto(idProduto As Integer)
        Try
            sql = $"SELECT * FROM produtos WHERE id_produto = {idProduto}"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                Dim form3 As New Form3()

                form3.CarregarDadosProduto(
                    idProduto,
                    rs.Fields("nome_produto").Value.ToString(),
                    rs.Fields("categoria").Value.ToString(),
                    rs.Fields("descricao").Value.ToString(),
                    rs.Fields("imagem_url").Value.ToString(),
                    rs.Fields("tipo_desconto").Value.ToString(),
                    Convert.ToInt32(rs.Fields("quantidade_estoque").Value),
                    Convert.ToDecimal(rs.Fields("preco_descontado").Value),
                    Convert.ToDecimal(rs.Fields("porcentagem_desconto").Value),
                    Convert.ToDecimal(rs.Fields("preco").Value),
                    Convert.ToDateTime(rs.Fields("data_vencimento").Value),
                    rs.Fields("unidade").Value.ToString(),
                    rs.Fields("status_produto").Value.ToString()
                )
                editandoProduto = True
                idProdutoEditando = idProduto
                form3.Show()
            Else
                MsgBox("Produto não encontrado!", MsgBoxStyle.Exclamation, "Aviso")
            End If
        Catch ex As Exception
            MsgBox("Erro ao carregar produto: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Function CalcularDiasRestantes(dataVencimento As Date) As Integer
        Dim dias As Integer = CInt((dataVencimento - Date.Today).TotalDays)
        Return If(dias < 0, 0, dias)
    End Function

    Private Sub AdicionarQuantidade(idProduto As Integer)
        MessageBox.Show($"Adicionar quantidade ao produto ID: {idProduto}")
    End Sub

    Private Sub ExcluirProduto(idProduto As Integer, card As Panel)
        Dim resultado As DialogResult = MessageBox.Show(
        "Deseja realmente deletar o produto?" & vbNewLine & "Esta ação não pode ser desfeita.",
        "ATENÇÃO",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question
    )

        If resultado = DialogResult.Yes Then
            Try
                flowPanelProdutos.Controls.Remove(card)

                Dim sql As String = $"DELETE FROM produtos WHERE id_produto = {idProduto}"
                db.Execute(sql)

                MessageBox.Show("Produto excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Catch ex As Exception
                MessageBox.Show("Erro ao excluir produto: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
                CarregarProdutosNoFlowPanel()
            End Try
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CarregarProdutosNoFlowPanel("Orgânicos")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        CarregarProdutosNoFlowPanel("Frutas")
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        CarregarProdutosNoFlowPanel("Legumes")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        CarregarProdutosNoFlowPanel("Ervas")
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CarregarProdutosNoFlowPanel()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Dim textoPesquisa As String = TextBox1.Text.Trim()

        If String.IsNullOrEmpty(textoPesquisa) Then
            CarregarProdutosNoFlowPanel()
        Else
            FiltrarProdutosPorNome(textoPesquisa)
        End If
    End Sub

    Private Sub FiltrarProdutosPorNome(nomeProduto As String)
        flowPanelProdutos.Controls.Clear()

        Dim sql As String = $"SELECT * FROM produtos WHERE nome_produto LIKE '%{nomeProduto}%' ORDER BY nome_produto"

        Dim rs As ADODB.Recordset = db.Execute(sql)

        While Not rs.EOF
            Dim cardProduto As Panel = CriarCardProduto(rs)
            flowPanelProdutos.Controls.Add(cardProduto)
            rs.MoveNext()
        End While

        If Not rs Is Nothing Then
            If rs.State = 1 Then
                rs.Close()
            End If
        End If
    End Sub

    Private Sub Form5_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        CarregarProdutosNoFlowPanel()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub flowPanelProdutos_Paint(sender As Object, e As PaintEventArgs) Handles flowPanelProdutos.Paint

    End Sub
End Class