﻿Public Class Form6
    Private motivoSelecionado As String = ""
    Private Sub cadastrar_venda_Click(sender As Object, e As EventArgs) Handles cadastrar_venda.Click
        If String.IsNullOrEmpty(motivoSelecionado) Then
            MsgBox("Selecione um motivo para o descarte!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If

        If String.IsNullOrEmpty(id_produto.Text.Trim) Then MsgBox("ID Produto vazio!")
        If categoria.SelectedIndex = -1 Then MsgBox("Categoria não selecionada!")
        If unidade.SelectedIndex = -1 Then MsgBox("Unidade não selecionada!")
        If String.IsNullOrEmpty(quantidade_estoque.Text.Trim) Then MsgBox("Quantidade estoque vazia!")
        If String.IsNullOrEmpty(quantidade_descartada.Text.Trim) Then MsgBox("Quantidade descartada vazia!")
        If String.IsNullOrEmpty(txt_descricao.Text.Trim) Then MsgBox("Descrição vazia!")
        Try
            Dim dataVencimentoFormatada As String = data_vencimento.Value.ToString("yyyy-MM-dd HH:mm:ss")
            Dim dataAtualFormatada As String = data_atual.Value.ToString("yyyy-MM-dd HH:mm:ss")
            Dim Estoqueantigo As Decimal = CDec(quantidade_estoque.Text)
            Dim ID As Decimal = CDec(id_produto.Text)
            Dim qtde As Decimal = CDec(quantidade_descartada.Text)
            Dim EstoqueAtual As Decimal = (Estoqueantigo - qtde)
            If qtde > Estoqueantigo Then
                MsgBox($"Quantidade para descarte ({qtde}) é maior que o estoque disponível ({Estoqueantigo})!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ERRO")
                Exit Sub
            End If
            sql = $"insert into prod_descartados (id_produto, categoria, unidade, quantidade_estoque, quantidade_descartada, descricao_descarte, data_descarte, data_vencimento, motivo_descarte) values ('{id_produto.Text}','{categoria.Text}','{unidade.Text}','{quantidade_estoque.Text}','{quantidade_descartada.Text}','{txt_descricao.Text}','{dataAtualFormatada}','{dataVencimentoFormatada}','{motivoSelecionado}')"
            rs = db.Execute(sql)
            Try
                sql = $"update produtos set quantidade_estoque = '{EstoqueAtual}' where id_produto = '{ID}'"
                rs = db.Execute(sql)
                MsgBox("Estoque atualizado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                sql = $"select quantidade_estoque from produtos where id_produto = '{ID}'"
                rs = db.Execute(sql)
                If rs IsNot Nothing AndAlso Not rs.EOF Then
                    Dim estoquehoje As Decimal = CDec(rs.Fields("quantidade_estoque").Value)
                    If estoquehoje = 0 Then
                        sql = $"update produtos set status_produto = 'sem_estoque' where id_produto = '{ID}'"
                        rs = db.Execute(sql)
                    End If
                End If
                limpar_botoes()
            Catch ex As Exception
                MsgBox("Erro ao atualizar estoque!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            End Try
        Catch ex As Exception
            MsgBox("Erro ao gravar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub id_produto_KeyDown(sender As Object, e As KeyEventArgs) Handles id_produto.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                sql = $"select id_produto from prod_descartados where id_produto = '{id_produto.Text}'"
                rs = db.Execute(sql)
                If rs IsNot Nothing AndAlso Not rs.EOF Then
                    MsgBox("Produto já teve seu descarte realizado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    Exit Sub
                End If
                sql = $"SELECT * FROM produtos WHERE id_produto='{id_produto.Text}' AND status_produto NOT IN ('sem_estoque', 'indisponivel')"
                rs = db.Execute(sql)
                If rs.EOF Then
                    MsgBox("Produto indísponivel ou sem estoque!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                Else
                    quantidade_estoque.Text = rs.Fields(11).Value
                    nome_produto.Text = rs.Fields(1).Value
                    categoria.SelectedItem = rs.Fields(9).Value
                    unidade.SelectedItem = rs.Fields(4).Value
                    quantidade_estoque.ReadOnly = True
                    nome_produto.ReadOnly = True
                    categoria.Enabled = False
                    unidade.Enabled = False
                End If
            Catch ex As Exception
                MsgBox("Erro ao carregar dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            End Try
        End If
    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
        quantidade_estoque.ReadOnly = True
        nome_produto.ReadOnly = True
        categoria.Enabled = False
        unidade.Enabled = False
    End Sub

    Private Sub btn_vencido_Click(sender As Object, e As EventArgs) Handles btn_vencido.Click
        motivoSelecionado = "Vencido"
        btn_vencido.BackColor = Color.FromArgb(65, 112, 53)
        btn_deteriorado.BackColor = Color.White
        btn_danificado.BackColor = Color.White
        btn_outros.BackColor = Color.White
        btn_praga.BackColor = Color.White
        btn_qualidade.BackColor = Color.White
    End Sub

    Private Sub btn_deteriorado_Click(sender As Object, e As EventArgs) Handles btn_deteriorado.Click
        motivoSelecionado = "Deteriorado"
        btn_deteriorado.BackColor = Color.FromArgb(65, 112, 53)
        btn_vencido.BackColor = Color.White
        btn_qualidade.BackColor = Color.White
        btn_outros.BackColor = Color.White
        btn_praga.BackColor = Color.White
        btn_danificado.BackColor = Color.White
    End Sub

    Private Sub btn_danificado_Click(sender As Object, e As EventArgs) Handles btn_danificado.Click
        motivoSelecionado = "Danificado"
        btn_danificado.BackColor = Color.FromArgb(65, 112, 53)
        btn_vencido.BackColor = Color.White
        btn_qualidade.BackColor = Color.White
        btn_outros.BackColor = Color.White
        btn_praga.BackColor = Color.White
        btn_deteriorado.BackColor = Color.White
    End Sub

    Private Sub btn_praga_Click(sender As Object, e As EventArgs) Handles btn_praga.Click
        motivoSelecionado = "Praga"
        btn_praga.BackColor = Color.FromArgb(65, 112, 53)
        btn_vencido.BackColor = Color.White
        btn_qualidade.BackColor = Color.White
        btn_outros.BackColor = Color.White
        btn_deteriorado.BackColor = Color.White
        btn_danificado.BackColor = Color.White
    End Sub

    Private Sub btn_qualidade_Click(sender As Object, e As EventArgs) Handles btn_qualidade.Click
        motivoSelecionado = "Qualidade"
        btn_qualidade.BackColor = Color.FromArgb(65, 112, 53)
        btn_vencido.BackColor = Color.White
        btn_deteriorado.BackColor = Color.White
        btn_outros.BackColor = Color.White
        btn_praga.BackColor = Color.White
        btn_danificado.BackColor = Color.White
    End Sub

    Private Sub btn_outros_Click(sender As Object, e As EventArgs) Handles btn_outros.Click
        motivoSelecionado = "Outros"
        btn_outros.BackColor = Color.FromArgb(65, 112, 53)
        btn_vencido.BackColor = Color.White
        btn_qualidade.BackColor = Color.White
        btn_deteriorado.BackColor = Color.White
        btn_praga.BackColor = Color.White
        btn_danificado.BackColor = Color.White
    End Sub

    Private Sub limpar_botoes()
        motivoSelecionado = ""
        btn_vencido.BackColor = Color.White
        btn_qualidade.BackColor = Color.White
        btn_deteriorado.BackColor = Color.White
        btn_praga.BackColor = Color.White
        btn_danificado.BackColor = Color.White
        btn_outros.BackColor = Color.White
        id_produto.Clear()
        quantidade_descartada.Clear()
        nome_produto.Clear()
        quantidade_estoque.Clear()
        txt_descricao.Clear()
        unidade.SelectedIndex = -1
        categoria.SelectedIndex = -1
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub id_produto_TextChanged(sender As Object, e As EventArgs) Handles id_produto.TextChanged

    End Sub
End Class