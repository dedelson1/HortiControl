﻿
Public Class Form2
    Private panelNaFrente As Boolean = False

    Private Sub btn_addprod_Click(sender As Object, e As EventArgs)
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub menu_Click(sender As Object, e As EventArgs) Handles menu.Click
        If panelNaFrente Then
            Panel1.SendToBack()
            panelNaFrente = False
        Else
            Panel1.BringToFront()
            panelNaFrente = True
        End If
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Panel1.SendToBack()
        'Panel13.Visible = False
        conectar_banco()
        atualizarDashboard()
        ArredondarPanels()
    End Sub
    Private Sub ArredondarPanels()
        ArredondarPanel(Panel1, 20)
        ArredondarPanel(Panel2, 20)
        ArredondarPanel(Panel3, 20)
        ArredondarPanel(Panel4, 20)
        ArredondarPanel(Panel5, 20)
        ArredondarPanel(Panel6, 20)
        ArredondarPanel(Panel7, 20)
        ArredondarPanel(Panel8, 20)
        'ArredondarPanel(Panel13, 20)
    End Sub

    Private Sub ArredondarPanel(panel As Control, raio As Integer)
        Dim gp As New Drawing2D.GraphicsPath()

        gp.AddArc(0, 0, raio, raio, 180, 90)
        gp.AddArc(panel.Width - raio, 0, raio, raio, 270, 90)
        gp.AddArc(panel.Width - raio, panel.Height - raio, raio, raio, 0, 90)
        gp.AddArc(0, panel.Height - raio, raio, raio, 90, 90)
        gp.CloseFigure()

        panel.Region = New Region(gp)
    End Sub

    Private Sub NovaVendaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NovaVendaToolStripMenuItem.Click
        If acesso = "gestor" OrElse acesso = "vendedor" OrElse acesso = "compra/vendas" Then
            Form4.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If
    End Sub

    Private Sub CadastrarProdutoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CadastrarProdutoToolStripMenuItem.Click
        If acesso = "gestor" OrElse acesso = "estoquista" OrElse acesso = "compra/vendas" Then
            Form3.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If

    End Sub

    Public Sub atualizarDashboard()
        barra_produtos.Minimum = 0
        barra_produtos.Maximum = 10
        barra_produtos.Value = 0
        Try
            sql = $"select count(id_produto) from produtos"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_produtos.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_produtos.Text = "0"
            End If
            rs.Close()

            sql = $"select sum(preco) from produtos"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_valorestoque.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_valorestoque.Text = "0"
            End If
            rs.Close()

            sql = $"select COUNT(status_produto) from produtos where status_produto in ('sem_estoque', 'indisponivel')"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_baixoestoque.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_baixoestoque.Text = "0"
            End If
            rs.Close()

            sql = $"SELECT COUNT(id_produto) FROM produtos WHERE data_vencimento <= CURDATE() + INTERVAL 7 DAY"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                Dim quantidade As Integer = CInt(rs.Fields(0).Value)
                lbl_expirantes.Text = quantidade.ToString()
                If quantidade > 0 Then
                    Panel13.Visible = True
                Else
                    Panel13.Visible = False
                End If
            Else
                lbl_expirantes.Text = "0"
            End If
            rs.Close()

            sql = "SELECT COUNT(id_produto) FROM produtos WHERE quantidade_estoque < 10 AND status_produto = 'publicado'"
            rs = db.Execute(sql)
            Dim quantidadeBaixoEstoque As Integer = 0
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                quantidadeBaixoEstoque = CInt(rs.Fields(0).Value)
            End If
            rs.Close()
            Dim produtoBaixoEstoque As String = ""
            Dim categoriaBaixoEstoque As String = ""
            Dim quantidadeEspecifica As Integer = 0
            If quantidadeBaixoEstoque > 0 Then
                sql = "SELECT nome_produto, categoria, quantidade_estoque FROM produtos WHERE quantidade_estoque < 10 AND status_produto = 'publicado' ORDER BY quantidade_estoque ASC LIMIT 1"
                rs = db.Execute(sql)
                If rs IsNot Nothing AndAlso Not rs.EOF Then
                    produtoBaixoEstoque = rs.Fields("nome_produto").Value.ToString()
                    categoriaBaixoEstoque = rs.Fields("categoria").Value.ToString()
                    quantidadeEspecifica = CInt(rs.Fields("quantidade_estoque").Value)
                End If
                rs.Close()
            End If
            If quantidadeBaixoEstoque > 0 Then
                lbl_produtos_baixoestoque.Text = produtoBaixoEstoque
                lbl_categorias_baixoestoque.Visible = True
                lbl_categorias_baixoestoque.Text = categoriaBaixoEstoque
                qtde_baixoestoque.Visible = True
                qtde_baixoestoque.Text = quantidadeEspecifica.ToString()
                barra_produtos.Visible = True
                If quantidadeEspecifica >= 10 Then
                    barra_produtos.Value = 10
                ElseIf quantidadeEspecifica <= 0 Then
                    barra_produtos.Value = 0
                Else
                    barra_produtos.Value = quantidadeEspecifica
                End If
                barra_produtos.ForeColor = Color.Red
                barra_produtos.Style = ProgressBarStyle.Continuous
            Else
                lbl_produtos_baixoestoque.Text = "Nenhum produto necessita de reabastecimento"
                lbl_categorias_baixoestoque.Visible = False
                qtde_baixoestoque.Visible = False
                barra_produtos.Visible = False
            End If

            sql = "SELECT COUNT(id_produto) FROM produtos WHERE data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND status_produto = 'publicado'"
            rs = db.Execute(sql)
            Dim quantidadeExpirantes As Integer = 0
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                quantidadeExpirantes = CInt(rs.Fields(0).Value)
            End If
            rs.Close()
            Dim produtoExpirante As String = ""
            Dim categoriaExpirante As String = ""
            Dim diasRestantes As Integer = 0
            If quantidadeExpirantes > 0 Then
                sql = "SELECT nome_produto, categoria, DATEDIFF(data_vencimento, CURDATE()) as dias_restantes FROM produtos WHERE data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND status_produto = 'publicado' ORDER BY data_vencimento ASC LIMIT 1"
                rs = db.Execute(sql)
                If rs IsNot Nothing AndAlso Not rs.EOF Then
                    produtoExpirante = rs.Fields("nome_produto").Value.ToString()
                    categoriaExpirante = rs.Fields("categoria").Value.ToString()
                    diasRestantes = CInt(rs.Fields("dias_restantes").Value)
                End If
                rs.Close()
            End If
            If quantidadeExpirantes > 0 Then
                lbl_produtos_expirantes.Text = produtoExpirante
                lbl_categorias_expirantes.Visible = True
                lbl_categorias_expirantes.Text = categoriaExpirante
                dias_expirantes.Visible = True
                dias_expirantes.Text = diasRestantes.ToString() & " dias"
            Else
                lbl_produtos_expirantes.Text = "Nenhum produto próximo do vencimento"
                lbl_categorias_expirantes.Visible = False
                dias_expirantes.Visible = False
            End If

            sql = $"select COUNT(id_produto) from produtos where categoria in ('Ervas')"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_ervas.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_ervas.Text = "0"
            End If
            rs.Close()
            sql = $"select COUNT(id_produto) from produtos where categoria in ('Frutas')"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_frutas.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_frutas.Text = "0"
            End If
            rs.Close()
            sql = $"select COUNT(id_produto) from produtos where categoria in ('Legumes')"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_legumes.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_legumes.Text = "0"
            End If
            rs.Close()
            sql = $"select COUNT(id_produto) from produtos where categoria in ('Organicos')"
            rs = db.Execute(sql)
            If rs IsNot Nothing AndAlso Not rs.EOF Then
                lbl_organicos.Text = rs.Fields(0).Value.ToString()
            Else
                lbl_organicos.Text = "0"
            End If
            rs.Close()

        Catch ex As Exception
            MsgBox("Erro ao carregar dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub EstoqueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EstoqueToolStripMenuItem.Click
        If acesso = "gestor" OrElse acesso = "estoquista" OrElse acesso = "compra/vendas" OrElse acesso = "vendedor" OrElse acesso = "qualidade" Then
            Form5.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If acesso = "gestor" OrElse acesso = "estoquista" OrElse acesso = "compra/vendas" OrElse acesso = "vendedor" OrElse acesso = "qualidade" Then
            Form5.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        If acesso = "gestor" OrElse acesso = "estoquista" OrElse acesso = "compra/vendas" OrElse acesso = "vendedor" OrElse acesso = "qualidade" Then
            Form5.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        If acesso = "gestor" OrElse acesso = "qualidade" Then
            Form6.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If
    End Sub

    Private Sub GerarRelatóriosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GerarRelatóriosToolStripMenuItem.Click
        If acesso = "gestor" OrElse acesso = "qualidade" OrElse acesso = "financeiro" Then
            Form7.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If

    End Sub

    Private Sub CadastrarClienteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CadastrarClienteToolStripMenuItem.Click
        If acesso = "gestor" Then
            Form8.Show()
            Me.Hide()
        Else
            MsgBox("Acesso Restrito!" & vbNewLine & "Contate um Administrador.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
        End If

    End Sub

    Private Sub LOGOUTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LOGOUTToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()
        Logado = False
        acesso = ""
    End Sub
End Class