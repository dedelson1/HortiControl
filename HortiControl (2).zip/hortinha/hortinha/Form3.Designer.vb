﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_imagemurl = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnCarregarURL = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.box_imagem = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmb_status = New System.Windows.Forms.ComboBox()
        Me.cmb_categoria = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txt_usuario = New System.Windows.Forms.MaskedTextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txt_qtdestoque = New System.Windows.Forms.TextBox()
        Me.txt_senha = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.data_vencimento = New System.Windows.Forms.MaskedTextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btn_salvar = New System.Windows.Forms.Button()
        Me.btn_cancel = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.txt_preco = New System.Windows.Forms.MaskedTextBox()
        Me.lbl_precofinal = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.preco_discont = New System.Windows.Forms.TextBox()
        Me.porc_discont = New System.Windows.Forms.TextBox()
        Me.txt_descricao = New System.Windows.Forms.RichTextBox()
        Me.txt_nomeprod = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.check_precofixo = New System.Windows.Forms.CheckBox()
        Me.check_porcentagem = New System.Windows.Forms.CheckBox()
        Me.check_semdiscont = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cmb_descricaoprod = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Panel1.SuspendLayout()
        CType(Me.box_imagem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Imagem do Produto"
        '
        'txt_imagemurl
        '
        Me.txt_imagemurl.Location = New System.Drawing.Point(57, 391)
        Me.txt_imagemurl.Name = "txt_imagemurl"
        Me.txt_imagemurl.Size = New System.Drawing.Size(168, 20)
        Me.txt_imagemurl.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label2.Location = New System.Drawing.Point(56, 375)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Imagem URL"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label3.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label3.Location = New System.Drawing.Point(57, 414)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(171, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Apenas arquivos de imagem *.png,"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel1.Controls.Add(Me.btnCarregarURL)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.box_imagem)
        Me.Panel1.Location = New System.Drawing.Point(24, 143)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(231, 337)
        Me.Panel1.TabIndex = 6
        '
        'btnCarregarURL
        '
        Me.btnCarregarURL.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.btnCarregarURL.ForeColor = System.Drawing.Color.White
        Me.btnCarregarURL.Location = New System.Drawing.Point(77, 302)
        Me.btnCarregarURL.Name = "btnCarregarURL"
        Me.btnCarregarURL.Size = New System.Drawing.Size(75, 23)
        Me.btnCarregarURL.TabIndex = 21
        Me.btnCarregarURL.Text = "Carregar "
        Me.btnCarregarURL.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label8.Location = New System.Drawing.Point(49, 284)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(130, 13)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = " *.jpg e *.jpeg são aceitos."
        '
        'box_imagem
        '
        Me.box_imagem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.box_imagem.Location = New System.Drawing.Point(32, 32)
        Me.box_imagem.Name = "box_imagem"
        Me.box_imagem.Size = New System.Drawing.Size(173, 197)
        Me.box_imagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.box_imagem.TabIndex = 1
        Me.box_imagem.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(53, 483)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 16)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Status"
        '
        'cmb_status
        '
        Me.cmb_status.FormattingEnabled = True
        Me.cmb_status.Items.AddRange(New Object() {"Publicado", "Indisponível", "Sem_Estoque"})
        Me.cmb_status.Location = New System.Drawing.Point(56, 515)
        Me.cmb_status.Name = "cmb_status"
        Me.cmb_status.Size = New System.Drawing.Size(168, 21)
        Me.cmb_status.TabIndex = 7
        '
        'cmb_categoria
        '
        Me.cmb_categoria.FormattingEnabled = True
        Me.cmb_categoria.Items.AddRange(New Object() {"Frutas", "Legumes", "Ervas", "Orgânicos"})
        Me.cmb_categoria.Location = New System.Drawing.Point(56, 590)
        Me.cmb_categoria.Name = "cmb_categoria"
        Me.cmb_categoria.Size = New System.Drawing.Size(168, 21)
        Me.cmb_categoria.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(54, 556)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(75, 16)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Categoria"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(53, 574)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 13)
        Me.Label7.TabIndex = 12
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(54, 574)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(107, 13)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Categoria do Produto"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(53, 502)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(92, 13)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Status do Produto"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(231, 515)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(24, 21)
        Me.PictureBox3.TabIndex = 14
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.hortinha.My.Resources.Resources.CADASTRO_DE_PRODUTOS
        Me.PictureBox1.Location = New System.Drawing.Point(0, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(780, 125)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txt_usuario)
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.txt_qtdestoque)
        Me.TabPage2.Controls.Add(Me.txt_senha)
        Me.TabPage2.Controls.Add(Me.Label36)
        Me.TabPage2.Controls.Add(Me.data_vencimento)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.Label23)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.btn_salvar)
        Me.TabPage2.Controls.Add(Me.btn_cancel)
        Me.TabPage2.Controls.Add(Me.Label21)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(437, 452)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Em estoque"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txt_usuario
        '
        Me.txt_usuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_usuario.Location = New System.Drawing.Point(77, 295)
        Me.txt_usuario.Mask = "999,999,999-99"
        Me.txt_usuario.Name = "txt_usuario"
        Me.txt_usuario.Size = New System.Drawing.Size(129, 20)
        Me.txt_usuario.TabIndex = 32
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.PictureBox4)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Location = New System.Drawing.Point(37, 115)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(365, 77)
        Me.Panel2.TabIndex = 5
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(3, 54)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(329, 13)
        Me.Label26.TabIndex = 3
        Me.Label26.Text = "ou quando os produtos estiverem a menos de 7 dias do vencimento."
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(3, 41)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(359, 13)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Você receberá notificações quando o estoque cair abaixo de 10 unidades "
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.PictureBox4.Image = Global.hortinha.My.Resources.Resources.Fa_Team_Fontawesome_FontAwesome_Triangle_Exclamation_32
        Me.PictureBox4.Location = New System.Drawing.Point(21, 7)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(39, 31)
        Me.PictureBox4.TabIndex = 1
        Me.PictureBox4.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(66, 16)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(120, 15)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Alerta de Estoque"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(256, 277)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(38, 13)
        Me.Label35.TabIndex = 31
        Me.Label35.Text = "Senha"
        '
        'txt_qtdestoque
        '
        Me.txt_qtdestoque.Location = New System.Drawing.Point(37, 73)
        Me.txt_qtdestoque.Name = "txt_qtdestoque"
        Me.txt_qtdestoque.Size = New System.Drawing.Size(144, 20)
        Me.txt_qtdestoque.TabIndex = 4
        '
        'txt_senha
        '
        Me.txt_senha.Location = New System.Drawing.Point(259, 293)
        Me.txt_senha.Name = "txt_senha"
        Me.txt_senha.Size = New System.Drawing.Size(134, 20)
        Me.txt_senha.TabIndex = 28
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(74, 277)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(43, 13)
        Me.Label36.TabIndex = 30
        Me.Label36.Text = "Usuário"
        '
        'data_vencimento
        '
        Me.data_vencimento.Location = New System.Drawing.Point(243, 73)
        Me.data_vencimento.Mask = "00/00/0000"
        Me.data_vencimento.Name = "data_vencimento"
        Me.data_vencimento.Size = New System.Drawing.Size(150, 20)
        Me.data_vencimento.TabIndex = 3
        Me.data_vencimento.ValidatingType = GetType(Date)
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(33, 246)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(146, 18)
        Me.Label37.TabIndex = 29
        Me.Label37.Text = "Confirme a adição"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(240, 57)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(104, 13)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "Data de Vencimento"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(34, 57)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(121, 13)
        Me.Label22.TabIndex = 1
        Me.Label22.Text = "Quantidade em Estoque"
        '
        'btn_salvar
        '
        Me.btn_salvar.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.btn_salvar.Location = New System.Drawing.Point(259, 347)
        Me.btn_salvar.Name = "btn_salvar"
        Me.btn_salvar.Size = New System.Drawing.Size(134, 54)
        Me.btn_salvar.TabIndex = 27
        Me.btn_salvar.Text = "Salvar"
        Me.btn_salvar.UseVisualStyleBackColor = False
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(71, 347)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(135, 54)
        Me.btn_cancel.TabIndex = 26
        Me.btn_cancel.Text = "Cancelar"
        Me.btn_cancel.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(17, 22)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(213, 18)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Gerenciamento de Estoque"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txt_preco)
        Me.TabPage1.Controls.Add(Me.lbl_precofinal)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.preco_discont)
        Me.TabPage1.Controls.Add(Me.porc_discont)
        Me.TabPage1.Controls.Add(Me.txt_descricao)
        Me.TabPage1.Controls.Add(Me.txt_nomeprod)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.check_precofixo)
        Me.TabPage1.Controls.Add(Me.check_porcentagem)
        Me.TabPage1.Controls.Add(Me.check_semdiscont)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.cmb_descricaoprod)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(437, 452)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Geral"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'txt_preco
        '
        Me.txt_preco.Location = New System.Drawing.Point(6, 291)
        Me.txt_preco.Name = "txt_preco"
        Me.txt_preco.Size = New System.Drawing.Size(171, 20)
        Me.txt_preco.TabIndex = 33
        '
        'lbl_precofinal
        '
        Me.lbl_precofinal.AutoSize = True
        Me.lbl_precofinal.Location = New System.Drawing.Point(6, 432)
        Me.lbl_precofinal.Name = "lbl_precofinal"
        Me.lbl_precofinal.Size = New System.Drawing.Size(0, 13)
        Me.lbl_precofinal.TabIndex = 32
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(227, 393)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(96, 13)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "Preço Descontado"
        '
        'preco_discont
        '
        Me.preco_discont.Location = New System.Drawing.Point(230, 409)
        Me.preco_discont.Name = "preco_discont"
        Me.preco_discont.Size = New System.Drawing.Size(168, 20)
        Me.preco_discont.TabIndex = 30
        '
        'porc_discont
        '
        Me.porc_discont.Location = New System.Drawing.Point(9, 409)
        Me.porc_discont.Name = "porc_discont"
        Me.porc_discont.Size = New System.Drawing.Size(168, 20)
        Me.porc_discont.TabIndex = 28
        '
        'txt_descricao
        '
        Me.txt_descricao.Location = New System.Drawing.Point(9, 126)
        Me.txt_descricao.Name = "txt_descricao"
        Me.txt_descricao.Size = New System.Drawing.Size(418, 96)
        Me.txt_descricao.TabIndex = 19
        Me.txt_descricao.Text = ""
        '
        'txt_nomeprod
        '
        Me.txt_nomeprod.Location = New System.Drawing.Point(9, 67)
        Me.txt_nomeprod.Name = "txt_nomeprod"
        Me.txt_nomeprod.Size = New System.Drawing.Size(168, 20)
        Me.txt_nomeprod.TabIndex = 16
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 393)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(134, 13)
        Me.Label18.TabIndex = 29
        Me.Label18.Text = "Porcentagem do Desconto"
        '
        'check_precofixo
        '
        Me.check_precofixo.AutoSize = True
        Me.check_precofixo.Location = New System.Drawing.Point(317, 367)
        Me.check_precofixo.Name = "check_precofixo"
        Me.check_precofixo.Size = New System.Drawing.Size(76, 17)
        Me.check_precofixo.TabIndex = 27
        Me.check_precofixo.Text = "Preço Fixo"
        Me.check_precofixo.UseVisualStyleBackColor = True
        '
        'check_porcentagem
        '
        Me.check_porcentagem.AutoSize = True
        Me.check_porcentagem.Location = New System.Drawing.Point(163, 367)
        Me.check_porcentagem.Name = "check_porcentagem"
        Me.check_porcentagem.Size = New System.Drawing.Size(97, 17)
        Me.check_porcentagem.TabIndex = 26
        Me.check_porcentagem.Text = "Porcentagem%"
        Me.check_porcentagem.UseVisualStyleBackColor = True
        '
        'check_semdiscont
        '
        Me.check_semdiscont.AutoSize = True
        Me.check_semdiscont.Checked = True
        Me.check_semdiscont.CheckState = System.Windows.Forms.CheckState.Checked
        Me.check_semdiscont.Location = New System.Drawing.Point(9, 367)
        Me.check_semdiscont.Name = "check_semdiscont"
        Me.check_semdiscont.Size = New System.Drawing.Size(96, 17)
        Me.check_semdiscont.TabIndex = 25
        Me.check_semdiscont.Text = "Sem Desconto"
        Me.check_semdiscont.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 340)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(131, 16)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "Tipo de Desconto"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(227, 274)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(110, 13)
        Me.Label16.TabIndex = 23
        Me.Label16.Text = "Descrição do Produto"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 275)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(90, 13)
        Me.Label15.TabIndex = 22
        Me.Label15.Text = "Preço do Produto"
        '
        'cmb_descricaoprod
        '
        Me.cmb_descricaoprod.FormattingEnabled = True
        Me.cmb_descricaoprod.Items.AddRange(New Object() {"Quilograma (kg)", "Grama (g)", "Miligrama (mg)", "Unidade (un)", "Maço", "Caixa"})
        Me.cmb_descricaoprod.Location = New System.Drawing.Point(230, 290)
        Me.cmb_descricaoprod.Name = "cmb_descricaoprod"
        Me.cmb_descricaoprod.Size = New System.Drawing.Size(168, 21)
        Me.cmb_descricaoprod.TabIndex = 21
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 246)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(48, 16)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "Preço"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 110)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(110, 13)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Descrição do Produto"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(90, 13)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Nome do Produto"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(157, 18)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Informações Gerais"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(308, 149)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(445, 478)
        Me.TabControl1.TabIndex = 13
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(774, 639)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmb_categoria)
        Me.Controls.Add(Me.cmb_status)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_imagemurl)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HortiControl"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.box_imagem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents box_imagem As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_imagemurl As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cmb_status As ComboBox
    Friend WithEvents cmb_categoria As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents btnCarregarURL As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents txt_usuario As MaskedTextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents txt_qtdestoque As TextBox
    Friend WithEvents txt_senha As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents data_vencimento As MaskedTextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents btn_salvar As Button
    Friend WithEvents btn_cancel As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents txt_preco As MaskedTextBox
    Friend WithEvents lbl_precofinal As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents preco_discont As TextBox
    Friend WithEvents porc_discont As TextBox
    Friend WithEvents txt_descricao As RichTextBox
    Friend WithEvents txt_nomeprod As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents check_precofixo As CheckBox
    Friend WithEvents check_porcentagem As CheckBox
    Friend WithEvents check_semdiscont As CheckBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents cmb_descricaoprod As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TabControl1 As TabControl
End Class
