﻿Imports System.IO
Imports System.Text
Public Class Form7
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If cmb_relatorio.SelectedIndex = -1 Then
            MsgBox("Selecione um tipo de relatório!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            Exit Sub
        End If
        Try
            Select Case cmb_relatorio.SelectedItem.ToString()
                Case "Relatório de Estoque"
                    GerarRelatorioEstoqueExcel()
                Case "Relatório de Vendas"
                    GerarRelatorioVendasExcel()
                Case "Relatório de Usuários"
                    GerarRelatorioUsuariosExcel()
                Case "Relatório de Descarte"
                    GerarRelatorioDescarteExcel()
                Case "Relatório de Funcionários"
                    GerarRelatorioFuncionariosExcel()
            End Select
        Catch ex As Exception
            MsgBox("Erro ao selecionar relatório", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub GerarRelatorioEstoqueExcel()
        Try
            ' Criar conteúdo CSV
            Dim conteudo As New StringBuilder()

            ' Cabeçalho
            conteudo.AppendLine("ID Produto;Nome do Produto;Descrição;Preço;Unidade;Tipo Desconto;Porcentagem Desconto;Preço Descontado;Status;Categoria;Quantidade Estoque;Data Vencimento")

            ' Buscar dados do banco ORDENADO POR ID
            sql = "SELECT * FROM produtos ORDER BY id_produto"
            rs = db.Execute(sql)

            ' Verificar se há registros
            If rs Is Nothing OrElse rs.EOF Then
                MsgBox("Nenhum produto encontrado para gerar relatório!", MsgBoxStyle.Information, "Aviso")
                Exit Sub
            End If  ' CORREÇÃO: End If aqui

            While Not rs.EOF
                ' Usar métodos seguros para evitar erro de campo não encontrado
                Dim idProduto As String = ObterValorCampo(rs, "id_produto")
                Dim nomeProduto As String = ObterValorCampo(rs, "nome_produto")
                Dim descricao As String = ObterValorCampo(rs, "descricao")
                Dim preco As String = ObterValorDecimal(rs, "preco", "F2")
                Dim unidade As String = ObterValorCampo(rs, "unidade")
                Dim tipoDesconto As String = ObterValorCampo(rs, "tipo_desconto")
                Dim porcentagemDesconto As String = ObterValorDecimal(rs, "porcentagem_desconto", "F2")
                Dim precoDescontado As String = ObterValorDecimal(rs, "preco_descontado", "F2")
                Dim statusProduto As String = ObterValorCampo(rs, "status_produto")
                Dim categoria As String = ObterValorCampo(rs, "categoria")
                Dim quantidadeEstoque As String = ObterValorCampo(rs, "quantidade_estoque")
                Dim dataVencimento As String = ObterValorData(rs, "data_vencimento", "dd/MM/yyyy")

                conteudo.AppendLine(
                    $"{idProduto};" &
                    $"{nomeProduto};" &
                    $"{descricao};" &
                    $"{preco};" &
                    $"{unidade};" &
                    $"{tipoDesconto};" &
                    $"{porcentagemDesconto};" &
                    $"{precoDescontado};" &
                    $"{statusProduto};" &
                    $"{categoria};" &
                    $"{quantidadeEstoque};" &
                    $"{dataVencimento}"
                )
                rs.MoveNext()
            End While  ' CORREÇÃO: End While aqui

            ' Salvar arquivo
            Dim caminho As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) &
                                   $"\Relatorio_Estoque_{DateTime.Now:yyyyMMdd_HHmmss}.csv"

            File.WriteAllText(caminho, conteudo.ToString(), Encoding.UTF8)

            ' Abrir o arquivo no Excel
            Process.Start(caminho)

            MsgBox($"Relatório gerado com sucesso!{vbCrLf}Salvo em: {caminho}", MsgBoxStyle.Information, "Sucesso")

        Catch ex As Exception
            MsgBox("Erro ao gerar relatório: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Function ObterValorCampo(rs As Object, nomeCampo As String) As String
        Try
            If rs.Fields(nomeCampo).Value Is DBNull.Value OrElse rs.Fields(nomeCampo).Value Is Nothing Then
                Return ""
            Else
                Return rs.Fields(nomeCampo).Value.ToString()
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Private Function ObterValorDecimal(rs As Object, nomeCampo As String, formato As String) As String
        Try
            If rs.Fields(nomeCampo).Value Is DBNull.Value OrElse rs.Fields(nomeCampo).Value Is Nothing Then
                Return "0.00"
            Else
                Return CDec(rs.Fields(nomeCampo).Value).ToString(formato)
            End If
        Catch ex As Exception
            Return "0.00"
        End Try
    End Function

    Private Function ObterValorData(rs As Object, nomeCampo As String, formato As String) As String
        Try
            If rs.Fields(nomeCampo).Value Is DBNull.Value OrElse rs.Fields(nomeCampo).Value Is Nothing Then
                Return ""
            Else
                Return Format(CDate(rs.Fields(nomeCampo).Value), formato)
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function
    Private Sub GerarRelatorioVendasExcel()
        Try
            ' Criar conteúdo CSV
            Dim conteudo As New StringBuilder()

            ' Cabeçalho baseado na imagem
            conteudo.AppendLine("ID Produto;Categoria;Unidade;Quantidade Estoque;Quantidade Comprada;Preço Final;Data Venda;Pagamento")

            ' Buscar dados da tabela de vendas - ajuste o nome da tabela conforme seu banco
            sql = "SELECT * FROM cad_vendas ORDER BY data_venda DESC" ' Ajuste o nome da tabela e campo
            rs = db.Execute(sql)

            ' Verificar se há registros
            If rs Is Nothing OrElse rs.EOF Then
                MsgBox("Nenhuma venda encontrada para gerar relatório!", MsgBoxStyle.Information, "Aviso")
                Exit Sub
            End If

            While Not rs.EOF
                ' Usar métodos seguros para evitar erro de campo não encontrado
                Dim idProduto As String = ObterValorCampo(rs, "id_produto")
                Dim categoria As String = ObterValorCampo(rs, "categoria")
                Dim unidade As String = ObterValorCampo(rs, "unidade")
                Dim quantidadeEstoque As String = ObterValorCampo(rs, "quantidade_estoque")
                Dim quantidadeComprada As String = ObterValorCampo(rs, "quantidade_comprada")
                Dim precoFinal As String = ObterValorDecimal(rs, "precofinal", "F2")
                Dim dataVenda As String = ObterValorData(rs, "data_venda", "dd/MM/yyyy HH:mm:ss")
                Dim pagamento As String = ObterValorCampo(rs, "pagamento")

                conteudo.AppendLine(
                    $"{idProduto};" &
                    $"{categoria};" &
                    $"{unidade};" &
                    $"{quantidadeEstoque};" &
                    $"{quantidadeComprada};" &
                    $"{precoFinal};" &
                    $"{dataVenda};" &
                    $"{pagamento}"
                )
                rs.MoveNext()
            End While

            ' Salvar arquivo
            Dim caminho As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) &
                                   $"\Relatorio_Vendas_{DateTime.Now:yyyyMMdd_HHmmss}.csv"

            File.WriteAllText(caminho, conteudo.ToString(), Encoding.UTF8)

            ' Abrir o arquivo no Excel
            Process.Start(caminho)

            MsgBox($"Relatório de vendas gerado com sucesso!{vbCrLf}Salvo em: {caminho}", MsgBoxStyle.Information, "Sucesso")

        Catch ex As Exception
            MsgBox("Erro ao gerar relatório de vendas: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Function ObterValorDataHora(rs As Object, nomeCampo As String, formato As String) As String
        Try
            If rs.Fields(nomeCampo).Value Is DBNull.Value OrElse rs.Fields(nomeCampo).Value Is Nothing Then
                Return ""
            Else
                Return Format(CDate(rs.Fields(nomeCampo).Value), formato)
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Private Sub GerarRelatorioUsuariosExcel()
        Try
            ' Criar conteúdo CSV
            Dim conteudo As New StringBuilder()

            ' Cabeçalho
            conteudo.AppendLine("ID Usuário;CPF;Nome;Email;Data Nascimento;Nível Acesso")

            ' Buscar dados da tabela usuarios
            sql = "SELECT * FROM usuarios ORDER BY id_usuario"
            rs = db.Execute(sql)

            ' Verificar se há registros
            If rs Is Nothing OrElse rs.EOF Then
                MsgBox("Nenhum usuário encontrado para gerar relatório!", MsgBoxStyle.Information, "Aviso")
                Exit Sub
            End If

            While Not rs.EOF
                ' Usar métodos seguros para evitar erro de campo não encontrado
                Dim idUsuario As String = ObterValorCampo(rs, "id_usuario")
                Dim cpf As String = FormatarCPF(ObterValorCampo(rs, "cpf"))
                Dim nome As String = ObterValorCampo(rs, "nome")
                Dim email As String = ObterValorCampo(rs, "email")
                Dim dataNascimento As String = ObterValorData(rs, "data_nasc", "dd/MM/yyyy")
                Dim nivelAcesso As String = ObterValorCampo(rs, "nivel_acesso")

                conteudo.AppendLine(
                $"{idUsuario};" &
                $"{cpf};" &
                $"{nome};" &
                $"{email};" &
                $"{dataNascimento};" &
                $"{nivelAcesso}"
            )
                rs.MoveNext()
            End While

            ' Salvar arquivo
            Dim caminho As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) &
                               $"\Relatorio_Usuarios_{DateTime.Now:yyyyMMdd_HHmmss}.csv"

            File.WriteAllText(caminho, conteudo.ToString(), Encoding.UTF8)

            ' Abrir o arquivo no Excel
            Process.Start(caminho)

            MsgBox($"Relatório de usuários gerado com sucesso!{vbCrLf}Salvo em: {caminho}", MsgBoxStyle.Information, "Sucesso")

        Catch ex As Exception
            MsgBox("Erro ao gerar relatório de usuários: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Function FormatarCPF(cpf As String) As String
        If String.IsNullOrEmpty(cpf) Then Return ""

        cpf = New String(cpf.Where(Function(c) Char.IsDigit(c)).ToArray())

        If cpf.Length = 11 Then
            Return $"{cpf.Substring(0, 3)}.{cpf.Substring(3, 3)}.{cpf.Substring(6, 3)}-{cpf.Substring(9, 2)}"
        Else
            Return cpf
        End If
    End Function
    Private Sub GerarRelatorioDescarteExcel()
        Try
            ' Criar conteúdo CSV
            Dim conteudo As New StringBuilder()

            ' Cabeçalho baseado na imagem
            conteudo.AppendLine("ID Produto;Categoria;Unidade;Quantidade Estoque;Quantidade Descartada;Data Vencimento;Data Descarte;Motivo Descarte;Descrição Descarte")

            ' Buscar dados da tabela prod_descartados
            sql = "SELECT * FROM prod_descartados ORDER BY id_produto"
            rs = db.Execute(sql)

            ' Verificar se há registros
            If rs Is Nothing OrElse rs.EOF Then
                MsgBox("Nenhum descarte encontrado para gerar relatório!", MsgBoxStyle.Information, "Aviso")
                Exit Sub
            End If

            While Not rs.EOF
                ' Usar métodos seguros para evitar erro de campo não encontrado
                Dim idProduto As String = ObterValorCampo(rs, "id_produto")
                Dim categoria As String = ObterValorCampo(rs, "categoria")
                Dim unidade As String = ObterValorCampo(rs, "unidade")
                Dim quantidadeEstoque As String = ObterValorCampo(rs, "quantidade_estoque")
                Dim quantidadeDescartada As String = ObterValorCampo(rs, "quantidade_descartada")
                Dim dataVencimento As String = ObterValorData(rs, "data_vencimento", "dd/MM/yyyy HH:mm:ss")
                Dim dataDescarte As String = ObterValorData(rs, "data_descarte", "dd/MM/yyyy HH:mm:ss")
                Dim motivoDescarte As String = ObterValorCampo(rs, "motivo_descarte")
                Dim descricaoDescarte As String = ObterValorCampo(rs, "descricao_descarte")

                conteudo.AppendLine(
                $"{idProduto};" &
                $"{categoria};" &
                $"{unidade};" &
                $"{quantidadeEstoque};" &
                $"{quantidadeDescartada};" &
                $"{dataVencimento};" &
                $"{dataDescarte};" &
                $"{motivoDescarte};" &
                $"{descricaoDescarte}"
            )
                rs.MoveNext()
            End While

            ' Salvar arquivo
            Dim caminho As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) &
                               $"\Relatorio_Descartados_{DateTime.Now:yyyyMMdd_HHmmss}.csv"

            File.WriteAllText(caminho, conteudo.ToString(), Encoding.UTF8)

            ' Abrir o arquivo no Excel
            Process.Start(caminho)

            MsgBox($"Relatório de descartados gerado com sucesso!{vbCrLf}Salvo em: {caminho}", MsgBoxStyle.Information, "Sucesso")

        Catch ex As Exception
            MsgBox("Erro ao gerar relatório de descartados: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub GerarRelatorioFuncionariosExcel()
        Try
            ' Criar conteúdo CSV
            Dim conteudo As New StringBuilder()

            ' Cabeçalho
            conteudo.AppendLine("ID Funcionário;CPF;Nome;Email;Data Nascimento;Nível Acesso;Estado da Conta")

            ' Buscar dados da tabela usuarios
            sql = "SELECT * FROM usuarios ORDER BY id_usuario"
            rs = db.Execute(sql)

            ' Verificar se há registros
            If rs Is Nothing OrElse rs.EOF Then
                MsgBox("Nenhum funcionário encontrado para gerar relatório!", MsgBoxStyle.Information, "Aviso")
                Exit Sub
            End If

            While Not rs.EOF
                ' Usar métodos seguros para evitar erro de campo não encontrado
                Dim idUsuario As String = ObterValorCampo(rs, "id_usuario")
                Dim cpf As String = FormatarCPF(ObterValorCampo(rs, "cpf"))
                Dim nome As String = ObterValorCampo(rs, "nome")
                Dim email As String = ObterValorCampo(rs, "email")
                Dim dataNascimento As String = ObterValorData(rs, "data_nasc", "dd/MM/yyyy")
                Dim nivelAcesso As String = ObterValorCampo(rs, "nivel_acesso")
                Dim estadoConta As String = ObterValorCampo(rs, "estado_conta")

                ' Converter estado da conta para texto descritivo
                If estadoConta = "1" Then
                    estadoConta = "ATIVA"
                Else
                    estadoConta = "INATIVA"
                End If

                conteudo.AppendLine(
                $"{idUsuario};" &
                $"{cpf};" &
                $"{nome};" &
                $"{email};" &
                $"{dataNascimento};" &
                $"{nivelAcesso};" &
                $"{estadoConta}"
            )
                rs.MoveNext()
            End While

            ' Salvar arquivo
            Dim caminho As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) &
                               $"\Relatorio_Funcionarios_{DateTime.Now:yyyyMMdd_HHmmss}.csv"

            File.WriteAllText(caminho, conteudo.ToString(), Encoding.UTF8)

            ' Abrir o arquivo no Excel
            Process.Start(caminho)

            MsgBox($"Relatório de funcionários gerado com sucesso!{vbCrLf}Salvo em: {caminho}", MsgBoxStyle.Information, "Sucesso")

        Catch ex As Exception
            MsgBox("Erro ao gerar relatório de funcionários: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub
End Class