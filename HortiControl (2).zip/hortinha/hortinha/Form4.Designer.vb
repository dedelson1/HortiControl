﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl_preco = New System.Windows.Forms.Label()
        Me.quantidade_comprada = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.nome_produto = New System.Windows.Forms.TextBox()
        Me.label = New System.Windows.Forms.Label()
        Me.preco = New System.Windows.Forms.TextBox()
        Me.quantidade_estoque = New System.Windows.Forms.TextBox()
        Me.pagamento = New System.Windows.Forms.ComboBox()
        Me.data_venda = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.nome_cliente = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.unidade = New System.Windows.Forms.ComboBox()
        Me.categoria = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.id_produto = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btn_cancel = New System.Windows.Forms.Button()
        Me.cadastrar_venda = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.lbl_preco)
        Me.Panel1.Controls.Add(Me.quantidade_comprada)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.nome_produto)
        Me.Panel1.Controls.Add(Me.label)
        Me.Panel1.Controls.Add(Me.preco)
        Me.Panel1.Controls.Add(Me.quantidade_estoque)
        Me.Panel1.Controls.Add(Me.pagamento)
        Me.Panel1.Controls.Add(Me.data_venda)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.nome_cliente)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.unidade)
        Me.Panel1.Controls.Add(Me.categoria)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.id_produto)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(41, 116)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(319, 354)
        Me.Panel1.TabIndex = 1
        '
        'lbl_preco
        '
        Me.lbl_preco.AutoSize = True
        Me.lbl_preco.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_preco.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.lbl_preco.Location = New System.Drawing.Point(187, 242)
        Me.lbl_preco.Name = "lbl_preco"
        Me.lbl_preco.Size = New System.Drawing.Size(52, 13)
        Me.lbl_preco.TabIndex = 26
        Me.lbl_preco.Text = "Label14"
        '
        'quantidade_comprada
        '
        Me.quantidade_comprada.Location = New System.Drawing.Point(19, 239)
        Me.quantidade_comprada.Name = "quantidade_comprada"
        Me.quantidade_comprada.Size = New System.Drawing.Size(121, 20)
        Me.quantidade_comprada.TabIndex = 25
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(16, 223)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 13)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "Quantidade "
        '
        'nome_produto
        '
        Me.nome_produto.Location = New System.Drawing.Point(19, 115)
        Me.nome_produto.Name = "nome_produto"
        Me.nome_produto.Size = New System.Drawing.Size(287, 20)
        Me.nome_produto.TabIndex = 23
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Location = New System.Drawing.Point(16, 99)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(90, 13)
        Me.label.TabIndex = 22
        Me.label.Text = "Nome do Produto"
        '
        'preco
        '
        Me.preco.Location = New System.Drawing.Point(185, 196)
        Me.preco.Name = "preco"
        Me.preco.Size = New System.Drawing.Size(121, 20)
        Me.preco.TabIndex = 20
        '
        'quantidade_estoque
        '
        Me.quantidade_estoque.Location = New System.Drawing.Point(19, 196)
        Me.quantidade_estoque.Name = "quantidade_estoque"
        Me.quantidade_estoque.Size = New System.Drawing.Size(121, 20)
        Me.quantidade_estoque.TabIndex = 19
        '
        'pagamento
        '
        Me.pagamento.FormattingEnabled = True
        Me.pagamento.Items.AddRange(New Object() {"Dinheiro", "Cartão de Débito", "Cartão de Crédito", "PIX", "Outros"})
        Me.pagamento.Location = New System.Drawing.Point(185, 324)
        Me.pagamento.Name = "pagamento"
        Me.pagamento.Size = New System.Drawing.Size(121, 21)
        Me.pagamento.TabIndex = 17
        '
        'data_venda
        '
        Me.data_venda.Location = New System.Drawing.Point(19, 325)
        Me.data_venda.Name = "data_venda"
        Me.data_venda.Size = New System.Drawing.Size(121, 20)
        Me.data_venda.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(182, 309)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 13)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Forma de Pagamento"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 309)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Data da Venda"
        '
        'nome_cliente
        '
        Me.nome_cliente.Location = New System.Drawing.Point(19, 282)
        Me.nome_cliente.Name = "nome_cliente"
        Me.nome_cliente.Size = New System.Drawing.Size(287, 20)
        Me.nome_cliente.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(16, 266)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(85, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Nome do Cliente"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(182, 180)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(97, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Preço Unitário (R$)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(16, 180)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Quantidade em Estoque"
        '
        'unidade
        '
        Me.unidade.FormattingEnabled = True
        Me.unidade.Items.AddRange(New Object() {"Quilograma (kg)", "Grama (g)", "Miligrama (mg)", "Unidade (un)", "Maço", "Caixa"})
        Me.unidade.Location = New System.Drawing.Point(185, 153)
        Me.unidade.Name = "unidade"
        Me.unidade.Size = New System.Drawing.Size(121, 21)
        Me.unidade.TabIndex = 7
        '
        'categoria
        '
        Me.categoria.FormattingEnabled = True
        Me.categoria.Items.AddRange(New Object() {"Frutas", "Legumes", "Ervas", "Orgânicos"})
        Me.categoria.Location = New System.Drawing.Point(19, 153)
        Me.categoria.Name = "categoria"
        Me.categoria.Size = New System.Drawing.Size(121, 21)
        Me.categoria.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(182, 137)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Unidade"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Categoria"
        '
        'id_produto
        '
        Me.id_produto.Location = New System.Drawing.Point(19, 78)
        Me.id_produto.Name = "id_produto"
        Me.id_produto.Size = New System.Drawing.Size(287, 20)
        Me.id_produto.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "ID do Produto"
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(41, 493)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(319, 36)
        Me.btn_cancel.TabIndex = 21
        Me.btn_cancel.Text = "Cancelar"
        Me.btn_cancel.UseVisualStyleBackColor = True
        '
        'cadastrar_venda
        '
        Me.cadastrar_venda.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.cadastrar_venda.ForeColor = System.Drawing.SystemColors.Control
        Me.cadastrar_venda.Location = New System.Drawing.Point(424, 493)
        Me.cadastrar_venda.Name = "cadastrar_venda"
        Me.cadastrar_venda.Size = New System.Drawing.Size(319, 36)
        Me.cadastrar_venda.TabIndex = 18
        Me.cadastrar_venda.Text = "Cadastrar Venda"
        Me.cadastrar_venda.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(424, 116)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(319, 354)
        Me.Panel2.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(41, 116)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(319, 59)
        Me.Panel3.TabIndex = 19
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(192, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Preencha os dados da venda realizada"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Cadastrar Nova Venda"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label12)
        Me.Panel4.Location = New System.Drawing.Point(424, 116)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(319, 59)
        Me.Panel4.TabIndex = 21
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label12.Location = New System.Drawing.Point(14, 10)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(123, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Vendas Cadastradas"
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(424, 173)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(319, 297)
        Me.FlowLayoutPanel1.TabIndex = 0
        Me.FlowLayoutPanel1.WrapContents = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.hortinha.My.Resources.Resources.Inserir_um_título
        Me.PictureBox1.Location = New System.Drawing.Point(-2, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(805, 86)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(782, 555)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btn_cancel)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cadastrar_venda)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HortiControl"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents unidade As ComboBox
    Friend WithEvents categoria As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents id_produto As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents pagamento As ComboBox
    Friend WithEvents data_venda As DateTimePicker
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents nome_cliente As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents cadastrar_venda As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents preco As TextBox
    Friend WithEvents quantidade_estoque As TextBox
    Friend WithEvents btn_cancel As Button
    Friend WithEvents nome_produto As TextBox
    Friend WithEvents label As Label
    Friend WithEvents quantidade_comprada As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents lbl_preco As Label
End Class
