﻿Imports System.Net.Http
Imports System.IO
Public Class Form3

    Private Sub box_imagem_Click(sender As Object, e As EventArgs) Handles box_imagem.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\fotos\"
                .ShowDialog()
                imagem = .FileName
                imagem = imagem.Replace("\", "/")
                box_imagem.Load(imagem)
            End With
        Catch ex As Exception
            MsgBox("Erro ao carregar a imagem", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Async Sub btnCarregarURL_Click(sender As Object, e As EventArgs) Handles btnCarregarURL.Click
        Try
            If String.IsNullOrEmpty(txt_imagemurl.Text.Trim()) Then
                MsgBox("Digite uma URL válida!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                Exit Sub
            End If

            ' SEMPRE criar novo HttpClient
            Using httpClient As New HttpClient()
                httpClient.Timeout = TimeSpan.FromSeconds(30)
                Dim imageBytes As Byte() = Await httpClient.GetByteArrayAsync(txt_imagemurl.Text)

                Using ms As New MemoryStream(imageBytes)
                    Dim imagemOriginal As Image = Image.FromStream(ms)
                    Dim imagemRedimensionada As Image = RedimensionarImagem(imagemOriginal, 173, 197)
                    box_imagem.Image = imagemRedimensionada
                    imagemOriginal.Dispose()
                End Using
            End Using

            box_imagem.SizeMode = PictureBoxSizeMode.Zoom
            MsgBox("Mensagem carregada com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")

        Catch ex As Exception
            MsgBox("Erro ao carregar a imagem!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Function RedimensionarImagem(imagemOriginal As Image, largura As Integer, altura As Integer) As Image
        Dim novaImagem As New Bitmap(largura, altura)

        Using g As Graphics = Graphics.FromImage(novaImagem)
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            g.PixelOffsetMode = Drawing2D.PixelOffsetMode.HighQuality
            g.CompositingQuality = Drawing2D.CompositingQuality.HighQuality

            g.DrawImage(imagemOriginal, 0, 0, largura, altura)
        End Using

        Return novaImagem
    End Function

    Private Sub btn_salvar_Click(sender As Object, e As EventArgs)
        If cmb_categoria.SelectedIndex = -1 OrElse
           cmb_status.SelectedIndex = -1 OrElse
           String.IsNullOrEmpty(txt_usuario.Text.Trim) OrElse
           String.IsNullOrEmpty(txt_senha.Text.Trim) OrElse
           String.IsNullOrEmpty(data_vencimento.ToString.Trim) OrElse
           String.IsNullOrEmpty(txt_qtdestoque.Text.Trim) OrElse
           cmb_descricaoprod.SelectedIndex = -1 OrElse
           String.IsNullOrEmpty(txt_preco.Text.Trim) OrElse
           String.IsNullOrEmpty(txt_nomeprod.Text.Trim) OrElse
           String.IsNullOrEmpty(txt_descricao.Text.Trim) Then
            MsgBox("Preencha todos os campos!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If
        If data_vencimento.Text = Nothing OrElse data_vencimento.Text < DateTime.Today Then
            MsgBox("Data de vencimento inválida!" & vbNewLine & "Informe uma data futura válida", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            data_vencimento.Focus()
            Exit Sub
        End If
        Try
            Dim tipoDesconto As String = ""
            If check_semdiscont.Checked = True Then
                tipoDesconto = "Sem Desconto"
            ElseIf check_porcentagem.Checked = True Then
                tipoDesconto = "Porcentagem"
            ElseIf check_precofixo.Checked = True Then
                tipoDesconto = "Preço Fixo"
            End If
            Dim dataFormatada As String = Date.Parse(data_vencimento.Text).ToString("yyyy-MM-dd")
            Dim cpfLimpo As String = txt_usuario.Text.Replace(".", "").Replace("-", "").Trim()
            Dim senhaLimpa As String = txt_senha.Text.Trim()
            sql = $"select * from usuarios where cpf='{cpfLimpo}'"
            rs = db.Execute(sql)
            If rs.EOF Then
                MsgBox("Usuário não encontrado!" & vbNewLine & "Contate um Administrador", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_usuario.BackColor = Color.Red
            Else
                sql = $"select * from usuarios where cpf='{cpfLimpo}' and senha='{senhaLimpa}'"
                rs = db.Execute(sql)
                If rs.EOF Then
                    MsgBox("Acesso Negado!" & vbNewLine & "CPF ou senha incorretos", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    txt_usuario.BackColor = Color.Red
                    txt_senha.BackColor = Color.Red
                Else
                    sql = $"insert into produtos (nome_produto,descricao,preco,unidade,tipo_desconto,porcentagem_desconto,preco_descontado,status_produto,categoria,imagem_url,quantidade_estoque,data_vencimento,lote_produto,fornecedor_id) values (
    '{txt_nomeprod.Text}','{txt_descricao.Text}','{txt_preco.Text}','{cmb_descricaoprod.Text}','{tipoDesconto}','{porc_discont.Text}','{preco_discont.Text}','{cmb_status.Text}','{cmb_categoria.Text}','{txt_imagemurl.Text}','{txt_qtdestoque.Text}','{dataFormatada}')"
                    rs = db.Execute(sql)
                    MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                    limpar_cadastroprod()
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro ao gravar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub check_semdiscont_CheckedChanged(sender As Object, e As EventArgs) Handles check_semdiscont.CheckedChanged
        If check_semdiscont.Checked Then
            preco_discont.ReadOnly = True
            porc_discont.ReadOnly = True
            check_porcentagem.Checked = False
            check_precofixo.Checked = False
            porc_discont.Clear()
            preco_discont.Clear()
        End If
    End Sub

    Private Sub check_porcentagem_CheckedChanged(sender As Object, e As EventArgs) Handles check_porcentagem.CheckedChanged
        If check_porcentagem.Checked Then
            preco_discont.ReadOnly = True
            porc_discont.ReadOnly = False
            check_semdiscont.Checked = False
            check_precofixo.Checked = False
            preco_discont.Clear()
            lbl_precofinal.Text = "Preço Final: R$ 0,00"
        End If
    End Sub

    Private Sub check_precofixo_CheckedChanged(sender As Object, e As EventArgs) Handles check_precofixo.CheckedChanged
        If check_precofixo.Checked Then
            preco_discont.ReadOnly = False
            porc_discont.ReadOnly = True
            check_semdiscont.Checked = False
            check_porcentagem.Checked = False
            porc_discont.Clear()
            lbl_precofinal.Text = "Porcentagem: 0% | Preço Final: R$ 0,00"
        End If
    End Sub

    Private Sub porc_discont_KeyDown(sender As Object, e As KeyEventArgs) Handles porc_discont.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                Dim precoOriginal As Decimal = CDec(txt_preco.Text)
                Dim porcentagemDesconto As Decimal = CDec(porc_discont.Text)
                Dim precoFinal As Decimal = precoOriginal - (precoOriginal * porcentagemDesconto / 100)
                lbl_precofinal.Text = "Preço Final: " & precoFinal.ToString("C2")
                e.SuppressKeyPress = True
            Catch
                lbl_precofinal.Text = "Preço Final: R$ 0,00"
            End Try
        End If
    End Sub

    Private Sub preco_discont_KeyDown(sender As Object, e As KeyEventArgs) Handles preco_discont.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                If String.IsNullOrEmpty(txt_preco.Text) OrElse String.IsNullOrEmpty(preco_discont.Text) Then
                    lbl_precofinal.Text = "Porcentagem: 0% | Preço Final: R$ 0,00"
                    Exit Sub
                End If
                Dim precoOriginal As Decimal = CDec(txt_preco.Text)
                Dim valorDesconto As Decimal = CDec(preco_discont.Text)
                Dim porcentagem As Decimal = (valorDesconto / precoOriginal) * 100
                Dim precoFinal As Decimal = precoOriginal - valorDesconto
                lbl_precofinal.Text = "Porcentagem: " & porcentagem.ToString("N2") & "% | Preço Final: " & precoFinal.ToString("C2")
                e.SuppressKeyPress = True
            Catch ex As Exception
                lbl_precofinal.Text = "Porcentagem: 0% | Preço Final: R$ 0,00"
            End Try
        End If
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs)
        Form2.Show()
        Me.Hide()
        Module2.AtualizarDashboardGlobal()
    End Sub

    Private Sub btn_salvar_Click_1(sender As Object, e As EventArgs) Handles btn_salvar.Click
        'If cmb_categoria.SelectedIndex = -1 OrElse
        'cmb_status.SelectedIndex = -1 OrElse
        'String.IsNullOrEmpty(txt_usuario.Text.Trim) OrElse
        'String.IsNullOrEmpty(txt_senha.Text.Trim) OrElse
        'String.IsNullOrEmpty(data_vencimento.ToString.Trim) OrElse
        'String.IsNullOrEmpty(txt_qtdestoque.Text.Trim) OrElse
        'cmb_descricaoprod.SelectedIndex = -1 OrElse
        'String.IsNullOrEmpty(txt_preco.Text.Trim) OrElse
        'String.IsNullOrEmpty(txt_nomeprod.Text.Trim) OrElse
        'String.IsNullOrEmpty(txt_descricao.Text.Trim) Then
        'MsgBox("Preencha todos os campos!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        'Exit Sub
        'End If
        If data_vencimento.Text = Nothing OrElse data_vencimento.Text < DateTime.Today Then
            MsgBox("Data de vencimento inválida!" & vbNewLine & "Informe uma data futura válida", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            data_vencimento.Focus()
            Exit Sub
        End If
        Try
            Dim tipoDesconto As String = ""
            If check_semdiscont.Checked = True Then
                tipoDesconto = "Sem Desconto"
            ElseIf check_porcentagem.Checked = True Then
                tipoDesconto = "Porcentagem"
            ElseIf check_precofixo.Checked = True Then
                tipoDesconto = "Preço Fixo"
            End If
            Dim dataFormatada As String = Date.Parse(data_vencimento.Text).ToString("yyyy-MM-dd")
            Dim cpfLimpo As String = txt_usuario.Text.Replace(".", "").Replace("-", "").Trim()
            Dim senhaLimpa As String = txt_senha.Text.Trim()
            sql = $"select * from usuarios where cpf='{cpfLimpo}'"
            rs = db.Execute(sql)
            If rs.EOF Then
                MsgBox("Usuário não encontrado!" & vbNewLine & "Contate um Administrador", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_usuario.BackColor = Color.Red
            Else
                sql = $"select * from usuarios where cpf='{cpfLimpo}' and senha='{senhaLimpa}'"
                rs = db.Execute(sql)
                If rs.EOF Then
                    MsgBox("Acesso Negado!" & vbNewLine & "CPF ou senha incorretos", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    txt_usuario.BackColor = Color.Red
                    txt_senha.BackColor = Color.Red
                Else
                    ' ========== ALTERAÇÃO AQUI ==========
                    If editandoProduto Then
                        ' FAZ UPDATE - PRODUTO EXISTENTE
                        sql = $"update produtos set 
                           nome_produto='{txt_nomeprod.Text}',
                           descricao='{txt_descricao.Text}',
                           preco='{txt_preco.Text}',
                           unidade='{cmb_descricaoprod.Text}',
                           tipo_desconto='{tipoDesconto}',
                           porcentagem_desconto='{porc_discont.Text}',
                           preco_descontado='{preco_discont.Text}',
                           status_produto='{cmb_status.Text}',
                           categoria='{cmb_categoria.Text}',
                           imagem_url='{txt_imagemurl.Text}',
                           quantidade_estoque='{txt_qtdestoque.Text}',
                           data_vencimento='{dataFormatada}'
                           where id_produto={idProdutoEditando}"

                        rs = db.Execute(sql)
                        MsgBox("Produto atualizado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                        Me.Close()
                    Else
                        sql = $"insert into produtos (nome_produto,descricao,preco,unidade,tipo_desconto,porcentagem_desconto,preco_descontado,status_produto,categoria,imagem_url,quantidade_estoque,data_vencimento) values (
'{txt_nomeprod.Text}','{txt_descricao.Text}','{txt_preco.Text}','{cmb_descricaoprod.Text}','{tipoDesconto}','{porc_discont.Text}','{preco_discont.Text}','{cmb_status.Text}','{cmb_categoria.Text}','{txt_imagemurl.Text}','{txt_qtdestoque.Text}','{dataFormatada}')"
                        rs = db.Execute(sql)
                        MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                        limpar_cadastroprod()
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro ao gravar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub btn_cancel_Click_1(sender As Object, e As EventArgs) Handles btn_cancel.Click
        Form2.Show()
        Me.Hide()
        Module2.AtualizarDashboardGlobal()
    End Sub

    Private Sub txt_senha_GotFocus(sender As Object, e As EventArgs) Handles txt_senha.GotFocus
        txt_senha.PasswordChar = "*"
    End Sub

    Public Sub CarregarDadosProduto(idProduto As Integer, nome As String, categoria As String,
                               descricao As String, imagem_url As String, tipo_desconto As String,
                               quantidade As Integer, preco_desconto As Decimal,
                               porcentagem_desconto As Decimal, preco As Decimal,
                               dataVencimento As Date, unidade As String, statusProduto As String)
        txt_nomeprod.Text = nome
        cmb_categoria.Text = categoria
        txt_qtdestoque.Text = quantidade.ToString()
        txt_preco.Text = preco.ToString("F2")
        data_vencimento.Text = dataVencimento.ToString("dd/MM/yyyy")
        txt_imagemurl.Text = imagem_url
        txt_descricao.Text = descricao
        If tipo_desconto = "Sem Desconto" Then
            check_semdiscont.Checked = True
        ElseIf tipo_desconto = "Porcentagem" Then
            check_porcentagem.Checked = True
            porc_discont.Text = porcentagem_desconto.ToString("F2")
        ElseIf tipo_desconto = "Preço Fixo" Then
            check_precofixo.Checked = True
            preco_discont.Text = preco_desconto.ToString("F2")
        End If
        cmb_descricaoprod.Text = unidade
        cmb_status.Text = statusProduto
    End Sub


End Class