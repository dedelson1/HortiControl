﻿Imports System.Net.Http

Module Module1
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public sql, nivelacesso, nomeusuario, imagem, resp As String
    Public resultado As Decimal
    Public editandoProduto As Boolean = False
    Public idProdutoEditando As Integer = 0
    Public acesso As String = ""
    Public Logado As Boolean = False
    Sub conectar_banco()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("DRIVER={MySQL ODBC 3.51 Driver};SERVER=localhost;DATABASE=projeto_adsva2;UID=root;PWD=usbw;port=3307;option3;")
            'MsgBox("Conectado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
    Sub limpar_cadvendas()
        Try
            With Form4
                .id_produto.Clear()
                .nome_cliente.Clear()
                .nome_produto.Clear()
                .quantidade_estoque.Clear()
                .quantidade_comprada.Clear()
                .lbl_preco.Text = "Subtotal = 0.00"
                .preco.Clear()
                .pagamento.SelectedIndex = -1
                .unidade.SelectedIndex = -1
                .categoria.SelectedIndex = -1
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Sub limpar_cadastroprod()
        Try
            With Form3
                .txt_nomeprod.Clear()
                .txt_descricao.Clear()
                .txt_preco.Clear()
                .txt_imagemurl.Clear()
                .txt_qtdestoque.Clear()
                .txt_usuario.Clear()
                .txt_senha.Clear()
                .data_vencimento.Clear()
                .porc_discont.Clear()
                .preco_discont.Clear()
                .lbl_precofinal.Text = ""
                .cmb_descricaoprod.SelectedIndex = -1
                .cmb_status.SelectedIndex = -1
                .cmb_categoria.SelectedIndex = -1
                .box_imagem.Image = Nothing
                editandoProduto = False
                idProdutoEditando = 0
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub
End Module
