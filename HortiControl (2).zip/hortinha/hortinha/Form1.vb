﻿Imports System.ComponentModel
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
        vizu_senha.Checked = False
        txt_senha.PasswordChar = "*"
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Try
            Dim cpfLimpo As String = txt_usuario.Text.Replace(".", "").Replace("-", "").Trim()
            Dim senhaLimpa As String = txt_senha.Text.Trim()
            sql = $"select * from usuarios where cpf='{cpfLimpo}'"
            rs = db.Execute(sql)
            If rs.EOF Then
                MsgBox("Usuário não encontrado!" & vbNewLine & "Contate um Administrador", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                txt_usuario.BackColor = Color.Red
            Else
                Dim estadoConta As String = rs.Fields("estado_conta").Value.ToString()
                If estadoConta = "0" Then
                    MsgBox("Conta inativa!" & vbNewLine & "Não é possível acessar o sistema." & vbNewLine & "Contate um Administrador", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ACESSO NEGADO")
                    txt_usuario.BackColor = Color.Red
                    txt_senha.BackColor = Color.Red
                    Exit Sub
                End If

                sql = $"select * from usuarios where cpf='{cpfLimpo}' and senha='{senhaLimpa}'"
                rs = db.Execute(sql)
                If rs.EOF Then
                    MsgBox("Acesso Negado!" & vbNewLine & "CPF ou senha incorretos", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    txt_usuario.BackColor = Color.Red
                    txt_senha.BackColor = Color.Red
                Else
                    nivelacesso = rs.Fields("nivel_acesso").Value.ToString
                    nomeusuario = rs.Fields("nome").Value.ToString
                    MsgBox($"Bem-vindo, {nomeusuario}!" & vbNewLine & $"Nível: {nivelacesso}",
                       MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Acesso Permitido!")
                    acesso = rs.Fields("nivel_acesso").Value.ToString()
                    Logado = True
                    txt_senha.Clear()
                    txt_usuario.Clear()
                    Form2.Show()
                    Me.Hide()
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro de processamento: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub vizu_senha_Click(sender As Object, e As EventArgs) Handles vizu_senha.Click
        If vizu_senha.Checked Then
            txt_senha.PasswordChar = vbNullChar
        Else
            txt_senha.PasswordChar = "*"
        End If
    End Sub
    Private Sub txt_usuario_Click(sender As Object, e As EventArgs) Handles txt_usuario.Click
        txt_usuario.BackColor = Color.White
        txt_senha.BackColor = Color.White
    End Sub
    Private Sub txt_senha_Click(sender As Object, e As EventArgs) Handles txt_senha.Click
        txt_senha.BackColor = Color.White
        txt_usuario.BackColor = Color.White
    End Sub

    Private Sub txt_senha_GotFocus(sender As Object, e As EventArgs) Handles txt_senha.GotFocus
        txt_senha.PasswordChar = "*"
    End Sub

    Private Sub vizu_senha_CheckedChanged(sender As Object, e As EventArgs) Handles vizu_senha.CheckedChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class
