﻿Public Class Form8
    Private usuarioEditando As Boolean = False
    Private cpfAtual As String = ""
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles box_imagem.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\fotos\"
                .ShowDialog()
                imagem = .FileName
                imagem = imagem.Replace("\", "/")
                Dim imagemOriginal As Image = Image.FromFile(imagem)
                Dim imagemRedimensionada As Image = RedimensionarImagem(imagemOriginal, 104, 132)
                box_imagem.Image = imagemRedimensionada
                imagemOriginal.Dispose()
            End With
        Catch ex As Exception
            MsgBox("Erro ao carregar a imagem", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub
    Private Function RedimensionarImagem(imagemOriginal As Image, largura As Integer, altura As Integer) As Image
        Dim novaImagem As New Bitmap(largura, altura)

        Using g As Graphics = Graphics.FromImage(novaImagem)
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            g.PixelOffsetMode = Drawing2D.PixelOffsetMode.HighQuality
            g.CompositingQuality = Drawing2D.CompositingQuality.HighQuality

            g.DrawImage(imagemOriginal, 0, 0, largura, altura)
        End Using

        Return novaImagem
    End Function

    Private Sub btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        If cmb_nivel.SelectedIndex = -1 OrElse
        cmb_status.SelectedIndex = -1 OrElse
       String.IsNullOrEmpty(txt_nome.Text.Trim) OrElse
       String.IsNullOrEmpty(txt_senha.Text.Trim) OrElse
       String.IsNullOrEmpty(txt_csenha.Text.Trim) OrElse
       String.IsNullOrEmpty(txt_cpf.Text.Trim) OrElse
       String.IsNullOrEmpty(txt_email.Text.Trim) Then
            MsgBox("Preencha todos os campos!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If
        Dim status As String = cmb_status.SelectedItem.ToString()
        Dim senha As String = txt_senha.Text.Trim()
        Dim csenha As String = txt_csenha.Text.Trim()
        If cmb_status.SelectedItem.ToString() = "ATIVA" Then
            status = "1"
        Else
            status = "0"
        End If
        If box_imagem.Image Is Nothing Then
            MsgBox("Selecione uma imagem!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If
        If senha <> csenha Then
            MsgBox("As senhas não coincidem!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If

        Try
            Dim datanascimento As String = data_nasc.Value.ToString("yyyy-MM-dd")
            Dim cpfLimpo As String = txt_cpf.Text.Replace(".", "").Replace("-", "").Replace(" ", "").Trim()
            If cpfLimpo.Length <> 11 Then
                MsgBox("CPF deve conter 11 dígitos!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
                Exit Sub
            End If
            If usuarioEditando Then
                sql = $"update usuarios set nome='{txt_nome.Text}', email='{txt_email.Text}', senha='{senha}', data_nasc='{datanascimento}', nivel_acesso='{cmb_nivel.Text}', estado_conta='{status}', foto='{imagem}' where cpf='{cpfAtual}'"
                rs = db.Execute(sql)
                MsgBox("Dados atualizados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                LimparCampos()
                CarregarDadosDataGridView()
                usuarioEditando = False
                cpfAtual = ""
            Else
                sql = $"select * from usuarios where cpf='{cpfLimpo}'"
                rs = db.Execute(sql)
                If Not rs.EOF Then
                    MsgBox("CPF já cadastrado no sistema!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
                    Exit Sub
                End If
                sql = $"insert into usuarios (cpf, nome, email, senha, data_nasc, nivel_acesso, estado_conta, foto) values (
'{cpfLimpo}','{txt_nome.Text}','{txt_email.Text}','{senha}','{datanascimento}','{cmb_nivel.Text}','{status}','{imagem}')"

                rs = db.Execute(sql)
                MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                LimparCampos()
                CarregarDadosDataGridView()
            End If
        Catch ex As Exception
            MsgBox("Erro ao gravar dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ERRO")
        End Try
    End Sub

    Private Sub LimparCampos()
        txt_nome.Clear()
        txt_email.Clear()
        txt_cpf.Clear()
        txt_senha.Clear()
        txt_csenha.Clear()
        cmb_nivel.SelectedIndex = -1
        cmb_status.SelectedIndex = -1
        box_imagem.Image = Nothing
        usuarioEditando = False
        cpfAtual = ""
    End Sub

    Private Sub txt_senha_GotFocus(sender As Object, e As EventArgs) Handles txt_senha.GotFocus
        txt_senha.PasswordChar = "*"
    End Sub

    Private Sub txt_csenha_TextChanged(sender As Object, e As EventArgs) Handles txt_csenha.TextChanged
        txt_csenha.PasswordChar = "*"
    End Sub

    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CarregarDadosDataGridView()
        conectar_banco()
        vizu_senha.Checked = False
        txt_senha.PasswordChar = "*"
        vizu_csenha.Checked = False
        txt_csenha.PasswordChar = "*"
    End Sub

    Private Sub vizu_senha_Click(sender As Object, e As EventArgs) Handles vizu_senha.Click
        If vizu_senha.Checked Then
            txt_senha.PasswordChar = vbNullChar
        Else
            txt_senha.PasswordChar = "*"
        End If
    End Sub

    Private Sub vizu_csenha_Click(sender As Object, e As EventArgs) Handles vizu_csenha.Click
        If vizu_csenha.Checked Then
            txt_csenha.PasswordChar = vbNullChar
        Else
            txt_csenha.PasswordChar = "*"
        End If
    End Sub


    Private Sub CarregarDadosDataGridView()
        Try
            conectar_banco() ' Certifique-se que a conexão está aberta

            sql = "SELECT id_usuario, cpf, nome, email, data_nasc, nivel_acesso, estado_conta FROM usuarios ORDER BY id_usuario"
            rs = db.Execute(sql)

            ' Limpa o DataGridView
            DataGridView1.Rows.Clear()

            ' Adiciona as colunas se não existirem
            If DataGridView1.Columns.Count = 0 Then
                DataGridView1.Columns.Add("id_usuario", "ID")
                DataGridView1.Columns.Add("cpf", "CPF")
                DataGridView1.Columns.Add("nome", "NOME")
                DataGridView1.Columns.Add("email", "E-MAIL")
                DataGridView1.Columns.Add("data_nasc", "DATA NASC.")
                DataGridView1.Columns.Add("nivel_acesso", "NÍVEL ACESSO")
                DataGridView1.Columns.Add("estado_conta", "ESTADO CONTA")
            End If

            ' Preenche o DataGridView com os dados
            While Not rs.EOF
                Dim id As String = If(IsDBNull(rs.Fields("id_usuario").Value), "", rs.Fields("id_usuario").Value.ToString())
                Dim cpf As String = If(IsDBNull(rs.Fields("cpf").Value), "", rs.Fields("cpf").Value.ToString())
                Dim nome As String = If(IsDBNull(rs.Fields("nome").Value), "", rs.Fields("nome").Value.ToString())
                Dim email As String = If(IsDBNull(rs.Fields("email").Value), "", rs.Fields("email").Value.ToString())
                Dim dataNasc As String = If(IsDBNull(rs.Fields("data_nasc").Value), "", rs.Fields("data_nasc").Value.ToString())
                Dim nivelAcesso As String = If(IsDBNull(rs.Fields("nivel_acesso").Value), "", rs.Fields("nivel_acesso").Value.ToString())
                Dim estadoConta As String = If(IsDBNull(rs.Fields("estado_conta").Value), "", rs.Fields("estado_conta").Value.ToString())

                ' Converte estado_conta para texto mais descritivo
                If estadoConta = "1" Then
                    estadoConta = "ATIVA"
                Else
                    estadoConta = "INATIVA"
                End If

                ' Formata o CPF
                If cpf.Length = 11 Then
                    cpf = cpf.Insert(9, "-").Insert(6, ".").Insert(3, ".")
                End If

                ' Adiciona a linha no DataGridView
                DataGridView1.Rows.Add(id, cpf, nome, email, dataNasc, nivelAcesso, estadoConta)

                rs.MoveNext()
            End While

            ' Ajusta o tamanho das colunas automaticamente
            DataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)

        Catch ex As Exception
            MsgBox("Erro ao carregar dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ERRO")
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        'Try
        With DataGridView1
                If .CurrentRow.Cells(8).Selected = True Then
                    Dim cpf As String = .CurrentRow.Cells(1).Value.ToString()
                    cpf = cpf.Replace(".", "").Replace("-", "").Replace(" ", "").Trim()
                    sql = $"SELECT * FROM usuarios WHERE cpf = '{cpf}'"
                    rs = db.Execute(sql)
                    If rs.EOF = False Then
                        resp = MsgBox("Deseja excluir o cpf: " & cpf & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                        If resp = MsgBoxResult.Yes Then
                            sql = $"delete from usuarios where cpf ='{cpf}'"
                            rs = db.Execute(sql)
                            MsgBox("Banco Atualizado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                        End If
                    End If
                    CarregarDadosDataGridView()
                ElseIf .CurrentRow.Cells(7).Selected = True Then
                    Dim cpf As String = .CurrentRow.Cells(1).Value.ToString()
                    cpf = cpf.Replace(".", "").Replace("-", "").Replace(" ", "").Trim()
                    sql = $"SELECT * FROM usuarios WHERE cpf = '{cpf}'"
                    rs = db.Execute(sql)
                    If rs.EOF = False Then
                        usuarioEditando = True
                        cpfAtual = cpf
                        txt_cpf.Text = rs.Fields("cpf").Value.ToString()
                        txt_nome.Text = rs.Fields("nome").Value.ToString()
                        txt_email.Text = rs.Fields("email").Value.ToString()
                        data_nasc.Value = Convert.ToDateTime(rs.Fields("data_nasc").Value)
                        cmb_nivel.Text = rs.Fields("nivel_acesso").Value.ToString()
                        txt_csenha.Text = rs.Fields("senha").Value.ToString()
                        txt_senha.Text = rs.Fields("senha").Value.ToString()
                        Dim foto As String = rs.Fields("foto").Value.ToString()
                        If Not String.IsNullOrEmpty(foto) Then
                            Dim imagemOriginal As Image = Image.FromFile(foto)
                            box_imagem.Image = RedimensionarImagem(imagemOriginal, 104, 132)
                            imagemOriginal.Dispose()
                        End If
                        Dim estadoConta As String = rs.Fields("estado_conta").Value.ToString()
                        If estadoConta = "1" Then
                            cmb_status.Text = "ATIVA"
                        Else
                            cmb_status.Text = "INATIVA"
                        End If
                        MsgBox("Dados carregados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                    End If
                Else
                    Exit Sub
                End If
            End With
        'Catch ex As Exception
        'MsgBox("Erro de processamento!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form2.Show()
        Me.Hide()
    End Sub
End Class