﻿Imports System.Net.NetworkInformation

Public Class Form4

    Private Sub cadastrar_venda_Click(sender As Object, e As EventArgs) Handles cadastrar_venda.Click
        If String.IsNullOrEmpty(id_produto.Text.Trim) OrElse
            categoria.SelectedIndex = -1 OrElse
            unidade.SelectedIndex = -1 OrElse
            String.IsNullOrEmpty(quantidade_estoque.Text.Trim) OrElse
            String.IsNullOrEmpty(quantidade_comprada.Text.Trim) OrElse
            String.IsNullOrEmpty(preco.Text.Trim) OrElse
            String.IsNullOrEmpty(nome_cliente.Text.Trim) OrElse
            pagamento.SelectedIndex = -1 Then
            MsgBox("Preencha todos os campos!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If
        Try
            Dim precoI As Decimal = CDec(preco.Text)
            Dim qtde As Decimal = CDec(quantidade_comprada.Text)
            Dim precofinal As Decimal = (precoI * qtde)
            Dim dataVendaFormatada As String = data_venda.Value.ToString("yyyy-MM-dd HH:mm:ss")
            Dim Estoqueantigo As Decimal = CDec(quantidade_estoque.Text)
            Dim ID As Decimal = CDec(id_produto.Text)
            sql = $"insert into cad_vendas (id_produto, categoria, unidade, quantidade_estoque, quantidade_comprada, precofinal, nome_cliente, data_venda, pagamento) values ('{id_produto.Text}','{categoria.Text}','{unidade.Text}','{quantidade_estoque.Text}','{quantidade_comprada.Text}','{precofinal}','{nome_cliente.Text}','{dataVendaFormatada}','{pagamento.Text}')"
            rs = db.Execute(sql)
            Try
                Dim estoquefinal As Decimal = (Estoqueantigo - qtde)
                sql = $"update produtos set quantidade_estoque = '{estoquefinal}' where id_produto = '{ID}'"
                rs = db.Execute(sql)
                MsgBox("Estoque atualizado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                sql = $"select quantidade_estoque from produtos where id_produto = '{ID}'"
                rs = db.Execute(sql)
                If rs IsNot Nothing AndAlso Not rs.EOF Then
                    Dim estoqueAtual As Decimal = CDec(rs.Fields("quantidade_estoque").Value)
                    If estoqueAtual = 0 Then
                        sql = $"update produtos set status_produto = 'sem_estoque' where id_produto = '{ID}'"
                        rs = db.Execute(sql)
                    End If
                End If
            Catch ex As Exception
                MsgBox("Erro ao atualizar estoque!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            End Try
            MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            AdicionarCartaoUltraSimples()
            limpar_cadvendas()
        Catch ex As Exception
            MsgBox("Erro ao gravar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
        lbl_preco.Text = "Subtotal = 0.00"
        preco.ReadOnly = True
        quantidade_estoque.ReadOnly = True
        nome_produto.ReadOnly = True
        categoria.Enabled = False
        unidade.Enabled = False
    End Sub

    Private Sub id_produto_KeyDown(sender As Object, e As KeyEventArgs) Handles id_produto.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                sql = $"select id_produto from cad_vendas where id_produto = '{id_produto.Text}'"
                rs = db.Execute(sql)
                If rs IsNot Nothing AndAlso Not rs.EOF Then
                    MsgBox("Produto já teve venda semanal!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    Exit Sub
                End If
                sql = $"SELECT * FROM produtos WHERE id_produto='{id_produto.Text}' AND status_produto NOT IN ('sem_estoque', 'indisponivel')"
                rs = db.Execute(sql)
                If rs.EOF Then
                    MsgBox("Produto indísponivel ou sem estoque!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                Else
                    Dim precoNormal As Decimal = rs.Fields(3).Value
                    Dim porcentagemDesconto As Decimal = rs.Fields("porcentagem_desconto").Value
                    Dim precoFixo As Decimal = rs.Fields("preco_descontado").Value
                    Dim precoFinal As Decimal = precoNormal
                    If porcentagemDesconto > 0 Then
                        precoFinal = precoFinal - (precoFinal * (porcentagemDesconto / 100))
                    End If
                    If precoFixo > 0 Then
                        precoFinal = precoFinal - precoFixo
                    End If
                    If precoFinal < 0 Then precoFinal = 0
                    preco.Text = precoFinal.ToString("N2")
                    quantidade_estoque.Text = rs.Fields(11).Value
                    nome_produto.Text = rs.Fields(1).Value
                    categoria.SelectedItem = rs.Fields(9).Value
                    unidade.SelectedItem = rs.Fields(4).Value
                    preco.ReadOnly = True
                    quantidade_estoque.ReadOnly = True
                    nome_produto.ReadOnly = True
                    categoria.Enabled = False
                    unidade.Enabled = False
                End If
            Catch ex As Exception
                MsgBox("Erro ao carregar dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            End Try
        End If
    End Sub

    Private Sub quantidade_comprada_KeyDown(sender As Object, e As KeyEventArgs) Handles quantidade_comprada.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                If CDec(quantidade_comprada.Text) > CDec(quantidade_estoque.Text) Then
                    MsgBox("Quantidade informada ultrapassa o estoque atual!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
                Else
                    Dim precoI As Decimal = CDec(preco.Text)
                    Dim qtde As Decimal = CDec(quantidade_comprada.Text)
                    Dim precofinal As Decimal = (precoI * qtde)
                    lbl_preco.Text = "Subtotal: " & precofinal
                End If
            Catch ex As Exception
                Exit Sub
            End Try
        End If
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        Form2.Show()
        Me.Hide()
        Module2.AtualizarDashboardGlobal()
    End Sub
    Private Sub AdicionarCartaoUltraSimples()
        ' Configurar o FlowLayoutPanel para vertical
        FlowLayoutPanel1.FlowDirection = FlowDirection.TopDown
        FlowLayoutPanel1.WrapContents = False
        FlowLayoutPanel1.AutoScroll = True

        Dim panel As New Panel With {
        .Size = New Size(300, 60),
        .BackColor = Color.White,
        .BorderStyle = BorderStyle.FixedSingle,
        .Margin = New Padding(5)
    }

        Dim precoI As Decimal = CDec(preco.Text)
        Dim qtde As Decimal = CDec(quantidade_comprada.Text)
        Dim total As Decimal = (precoI * qtde)

        ' Label com conteúdo centralizado
        panel.Controls.Add(New Label With {
        .Text = $"{nome_produto.Text} - {nome_cliente.Text} - R$ {total.ToString("0.00")}",
        .Location = New Point(10, 20),
        .Size = New Size(280, 20),
        .TextAlign = ContentAlignment.MiddleCenter ' 🔥 Centraliza o texto
    })

        FlowLayoutPanel1.Controls.Add(panel)
    End Sub

End Class