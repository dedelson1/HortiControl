﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.lbl_produtos = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lbl_valorestoque = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lbl_baixoestoque = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lbl_expirantes = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.qtde_baixoestoque = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.lbl_categorias_baixoestoque = New System.Windows.Forms.Label()
        Me.lbl_produtos_baixoestoque = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.barra_produtos = New System.Windows.Forms.ProgressBar()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.dias_expirantes = New System.Windows.Forms.Label()
        Me.lbl_categorias_expirantes = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbl_produtos_expirantes = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.lbl_organicos = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.lbl_ervas = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.lbl_legumes = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.lbl_frutas = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.DASHBOARDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VisãoGeralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VENDASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NovaVendaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PRODUTOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CadastrarProdutoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EstoqueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CLIENTESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CadastrarClienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RELATÓRIOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GerarRelatóriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.menu = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel13.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(238, 84)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 8
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.PictureBox3)
        Me.Panel2.Controls.Add(Me.lbl_produtos)
        Me.Panel2.Location = New System.Drawing.Point(238, 114)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(137, 95)
        Me.Panel2.TabIndex = 9
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(3, 11)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(106, 13)
        Me.Label22.TabIndex = 21
        Me.Label22.Text = "Total de Produtos"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(12, 76)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(114, 13)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "Produtos no Inventário"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.hortinha.My.Resources.Resources.Double_J_Design_Ravenna_3d_Box_16
        Me.PictureBox3.Location = New System.Drawing.Point(112, 11)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(34, 21)
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'lbl_produtos
        '
        Me.lbl_produtos.AutoSize = True
        Me.lbl_produtos.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_produtos.Location = New System.Drawing.Point(12, 49)
        Me.lbl_produtos.Name = "lbl_produtos"
        Me.lbl_produtos.Size = New System.Drawing.Size(96, 25)
        Me.lbl_produtos.TabIndex = 19
        Me.lbl_produtos.Text = "Label15"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Controls.Add(Me.lbl_valorestoque)
        Me.Panel3.Controls.Add(Me.PictureBox4)
        Me.Panel3.Location = New System.Drawing.Point(397, 114)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(137, 95)
        Me.Panel3.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 25)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "$"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(-3, 11)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(117, 13)
        Me.Label23.TabIndex = 22
        Me.Label23.Text = "Valor do Inventário"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 76)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(88, 13)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "Valor do Estoque"
        '
        'lbl_valorestoque
        '
        Me.lbl_valorestoque.AutoSize = True
        Me.lbl_valorestoque.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_valorestoque.Location = New System.Drawing.Point(39, 49)
        Me.lbl_valorestoque.Name = "lbl_valorestoque"
        Me.lbl_valorestoque.Size = New System.Drawing.Size(96, 25)
        Me.lbl_valorestoque.TabIndex = 21
        Me.lbl_valorestoque.Text = "Label17"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.hortinha.My.Resources.Resources.Designcontest_Ecommerce_Business_Money_16
        Me.PictureBox4.Location = New System.Drawing.Point(115, 11)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(34, 21)
        Me.PictureBox4.TabIndex = 1
        Me.PictureBox4.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label24)
        Me.Panel4.Controls.Add(Me.Label18)
        Me.Panel4.Controls.Add(Me.lbl_baixoestoque)
        Me.Panel4.Controls.Add(Me.PictureBox5)
        Me.Panel4.Location = New System.Drawing.Point(559, 114)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(137, 95)
        Me.Panel4.TabIndex = 11
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(3, 11)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(82, 13)
        Me.Label24.TabIndex = 23
        Me.Label24.Text = "Indisponíveis"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(11, 76)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(115, 13)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "Produtos Indisponíveis"
        '
        'lbl_baixoestoque
        '
        Me.lbl_baixoestoque.AutoSize = True
        Me.lbl_baixoestoque.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_baixoestoque.Location = New System.Drawing.Point(11, 49)
        Me.lbl_baixoestoque.Name = "lbl_baixoestoque"
        Me.lbl_baixoestoque.Size = New System.Drawing.Size(96, 25)
        Me.lbl_baixoestoque.TabIndex = 23
        Me.lbl_baixoestoque.Text = "Label19"
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.hortinha.My.Resources.Resources.Ampeross_Qetto_2_Danger_16
        Me.PictureBox5.Location = New System.Drawing.Point(105, 11)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(34, 21)
        Me.PictureBox5.TabIndex = 2
        Me.PictureBox5.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label25)
        Me.Panel5.Controls.Add(Me.Label20)
        Me.Panel5.Controls.Add(Me.lbl_expirantes)
        Me.Panel5.Location = New System.Drawing.Point(719, 114)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(137, 95)
        Me.Panel5.TabIndex = 12
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(3, 11)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(67, 13)
        Me.Label25.TabIndex = 25
        Me.Label25.Text = "Expirantes"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(11, 76)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(80, 13)
        Me.Label20.TabIndex = 26
        Me.Label20.Text = "Próximos 7 dias"
        '
        'lbl_expirantes
        '
        Me.lbl_expirantes.AutoSize = True
        Me.lbl_expirantes.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_expirantes.Location = New System.Drawing.Point(11, 49)
        Me.lbl_expirantes.Name = "lbl_expirantes"
        Me.lbl_expirantes.Size = New System.Drawing.Size(96, 25)
        Me.lbl_expirantes.TabIndex = 25
        Me.lbl_expirantes.Text = "Label21"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.qtde_baixoestoque)
        Me.Panel6.Controls.Add(Me.LinkLabel1)
        Me.Panel6.Controls.Add(Me.lbl_categorias_baixoestoque)
        Me.Panel6.Controls.Add(Me.lbl_produtos_baixoestoque)
        Me.Panel6.Controls.Add(Me.Label5)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Controls.Add(Me.barra_produtos)
        Me.Panel6.Location = New System.Drawing.Point(238, 231)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(296, 96)
        Me.Panel6.TabIndex = 12
        '
        'qtde_baixoestoque
        '
        Me.qtde_baixoestoque.AutoSize = True
        Me.qtde_baixoestoque.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.qtde_baixoestoque.Location = New System.Drawing.Point(246, 75)
        Me.qtde_baixoestoque.Name = "qtde_baixoestoque"
        Me.qtde_baixoestoque.Size = New System.Drawing.Size(45, 15)
        Me.qtde_baixoestoque.TabIndex = 20
        Me.qtde_baixoestoque.Text = "Label9"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Green
        Me.LinkLabel1.Location = New System.Drawing.Point(232, 10)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(57, 13)
        Me.LinkLabel1.TabIndex = 19
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Ver Mais..."
        Me.LinkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        '
        'lbl_categorias_baixoestoque
        '
        Me.lbl_categorias_baixoestoque.AutoSize = True
        Me.lbl_categorias_baixoestoque.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lbl_categorias_baixoestoque.Location = New System.Drawing.Point(18, 80)
        Me.lbl_categorias_baixoestoque.Name = "lbl_categorias_baixoestoque"
        Me.lbl_categorias_baixoestoque.Size = New System.Drawing.Size(39, 13)
        Me.lbl_categorias_baixoestoque.TabIndex = 18
        Me.lbl_categorias_baixoestoque.Text = "Label9"
        '
        'lbl_produtos_baixoestoque
        '
        Me.lbl_produtos_baixoestoque.AutoSize = True
        Me.lbl_produtos_baixoestoque.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_produtos_baixoestoque.Location = New System.Drawing.Point(18, 65)
        Me.lbl_produtos_baixoestoque.Name = "lbl_produtos_baixoestoque"
        Me.lbl_produtos_baixoestoque.Size = New System.Drawing.Size(52, 15)
        Me.lbl_produtos_baixoestoque.TabIndex = 17
        Me.lbl_produtos_baixoestoque.Text = "Label10"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label5.Location = New System.Drawing.Point(18, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(207, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Produtos que necessitam reabastecimento"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(18, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(155, 15)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Baixo Estoque de Produtos"
        '
        'barra_produtos
        '
        Me.barra_produtos.BackColor = System.Drawing.Color.Red
        Me.barra_produtos.ForeColor = System.Drawing.Color.Red
        Me.barra_produtos.Location = New System.Drawing.Point(174, 75)
        Me.barra_produtos.Name = "barra_produtos"
        Me.barra_produtos.Size = New System.Drawing.Size(66, 18)
        Me.barra_produtos.TabIndex = 0
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.LinkColor = System.Drawing.Color.Green
        Me.LinkLabel2.Location = New System.Drawing.Point(230, 10)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(57, 13)
        Me.LinkLabel2.TabIndex = 20
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Ver Mais..."
        Me.LinkLabel2.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.LinkLabel2)
        Me.Panel7.Controls.Add(Me.dias_expirantes)
        Me.Panel7.Controls.Add(Me.lbl_categorias_expirantes)
        Me.Panel7.Controls.Add(Me.Label7)
        Me.Panel7.Controls.Add(Me.lbl_produtos_expirantes)
        Me.Panel7.Controls.Add(Me.Label8)
        Me.Panel7.Location = New System.Drawing.Point(559, 231)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(297, 96)
        Me.Panel7.TabIndex = 12
        '
        'dias_expirantes
        '
        Me.dias_expirantes.AutoSize = True
        Me.dias_expirantes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dias_expirantes.Location = New System.Drawing.Point(230, 67)
        Me.dias_expirantes.Name = "dias_expirantes"
        Me.dias_expirantes.Size = New System.Drawing.Size(52, 15)
        Me.dias_expirantes.TabIndex = 21
        Me.dias_expirantes.Text = "Label13"
        '
        'lbl_categorias_expirantes
        '
        Me.lbl_categorias_expirantes.AutoSize = True
        Me.lbl_categorias_expirantes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lbl_categorias_expirantes.Location = New System.Drawing.Point(20, 80)
        Me.lbl_categorias_expirantes.Name = "lbl_categorias_expirantes"
        Me.lbl_categorias_expirantes.Size = New System.Drawing.Size(45, 13)
        Me.lbl_categorias_expirantes.TabIndex = 20
        Me.lbl_categorias_expirantes.Text = "Label11"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label7.Location = New System.Drawing.Point(20, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(179, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Produtos com validade de até 7 dias"
        '
        'lbl_produtos_expirantes
        '
        Me.lbl_produtos_expirantes.AutoSize = True
        Me.lbl_produtos_expirantes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_produtos_expirantes.Location = New System.Drawing.Point(20, 65)
        Me.lbl_produtos_expirantes.Name = "lbl_produtos_expirantes"
        Me.lbl_produtos_expirantes.Size = New System.Drawing.Size(52, 15)
        Me.lbl_produtos_expirantes.TabIndex = 19
        Me.lbl_produtos_expirantes.Text = "Label12"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(20, 10)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 15)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Produtos Expirantes"
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.Panel12)
        Me.Panel8.Controls.Add(Me.Panel11)
        Me.Panel8.Controls.Add(Me.Panel10)
        Me.Panel8.Controls.Add(Me.Panel9)
        Me.Panel8.Controls.Add(Me.Label4)
        Me.Panel8.Controls.Add(Me.Label3)
        Me.Panel8.Location = New System.Drawing.Point(238, 347)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(618, 121)
        Me.Panel8.TabIndex = 12
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.lbl_organicos)
        Me.Panel12.Controls.Add(Me.Label33)
        Me.Panel12.Location = New System.Drawing.Point(475, 47)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(137, 60)
        Me.Panel12.TabIndex = 11
        '
        'lbl_organicos
        '
        Me.lbl_organicos.AutoSize = True
        Me.lbl_organicos.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_organicos.Location = New System.Drawing.Point(17, 33)
        Me.lbl_organicos.Name = "lbl_organicos"
        Me.lbl_organicos.Size = New System.Drawing.Size(73, 20)
        Me.lbl_organicos.TabIndex = 26
        Me.lbl_organicos.Text = "Label32"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(17, 3)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(64, 13)
        Me.Label33.TabIndex = 25
        Me.Label33.Text = "Orgânicos"
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.lbl_ervas)
        Me.Panel11.Controls.Add(Me.Label31)
        Me.Panel11.Location = New System.Drawing.Point(323, 47)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(137, 60)
        Me.Panel11.TabIndex = 11
        '
        'lbl_ervas
        '
        Me.lbl_ervas.AutoSize = True
        Me.lbl_ervas.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ervas.Location = New System.Drawing.Point(18, 33)
        Me.lbl_ervas.Name = "lbl_ervas"
        Me.lbl_ervas.Size = New System.Drawing.Size(73, 20)
        Me.lbl_ervas.TabIndex = 24
        Me.lbl_ervas.Text = "Label30"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(18, 3)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(39, 13)
        Me.Label31.TabIndex = 23
        Me.Label31.Text = "Ervas"
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.lbl_legumes)
        Me.Panel10.Controls.Add(Me.Label29)
        Me.Panel10.Location = New System.Drawing.Point(171, 47)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(137, 60)
        Me.Panel10.TabIndex = 11
        '
        'lbl_legumes
        '
        Me.lbl_legumes.AutoSize = True
        Me.lbl_legumes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_legumes.Location = New System.Drawing.Point(14, 33)
        Me.lbl_legumes.Name = "lbl_legumes"
        Me.lbl_legumes.Size = New System.Drawing.Size(73, 20)
        Me.lbl_legumes.TabIndex = 22
        Me.lbl_legumes.Text = "Label28"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(14, 3)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(57, 13)
        Me.Label29.TabIndex = 21
        Me.Label29.Text = "Legumes"
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.lbl_frutas)
        Me.Panel9.Controls.Add(Me.Label27)
        Me.Panel9.Location = New System.Drawing.Point(21, 47)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(137, 60)
        Me.Panel9.TabIndex = 10
        '
        'lbl_frutas
        '
        Me.lbl_frutas.AutoSize = True
        Me.lbl_frutas.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_frutas.Location = New System.Drawing.Point(15, 34)
        Me.lbl_frutas.Name = "lbl_frutas"
        Me.lbl_frutas.Size = New System.Drawing.Size(73, 20)
        Me.lbl_frutas.TabIndex = 20
        Me.lbl_frutas.Text = "Label26"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(15, 3)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 13)
        Me.Label27.TabIndex = 19
        Me.Label27.Text = "Frutas"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 31)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Produtos por Categoria"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Distribuição por Categoria"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MenuStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DASHBOARDToolStripMenuItem, Me.VENDASToolStripMenuItem, Me.PRODUTOSToolStripMenuItem, Me.CLIENTESToolStripMenuItem, Me.RELATÓRIOSToolStripMenuItem, Me.LOGOUTToolStripMenuItem})
        Me.MenuStrip2.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow
        Me.MenuStrip2.Location = New System.Drawing.Point(39, 65)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(118, 132)
        Me.MenuStrip2.TabIndex = 16
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'DASHBOARDToolStripMenuItem
        '
        Me.DASHBOARDToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.DASHBOARDToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisãoGeralToolStripMenuItem})
        Me.DASHBOARDToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DASHBOARDToolStripMenuItem.Name = "DASHBOARDToolStripMenuItem"
        Me.DASHBOARDToolStripMenuItem.Size = New System.Drawing.Size(111, 21)
        Me.DASHBOARDToolStripMenuItem.Text = "DASHBOARD"
        '
        'VisãoGeralToolStripMenuItem
        '
        Me.VisãoGeralToolStripMenuItem.Name = "VisãoGeralToolStripMenuItem"
        Me.VisãoGeralToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.VisãoGeralToolStripMenuItem.Text = "📊 Visão Geral"
        '
        'VENDASToolStripMenuItem
        '
        Me.VENDASToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VENDASToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NovaVendaToolStripMenuItem})
        Me.VENDASToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VENDASToolStripMenuItem.Name = "VENDASToolStripMenuItem"
        Me.VENDASToolStripMenuItem.Size = New System.Drawing.Size(111, 21)
        Me.VENDASToolStripMenuItem.Text = "VENDAS"
        '
        'NovaVendaToolStripMenuItem
        '
        Me.NovaVendaToolStripMenuItem.Name = "NovaVendaToolStripMenuItem"
        Me.NovaVendaToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.NovaVendaToolStripMenuItem.Text = "🛒 Nova Venda"
        '
        'PRODUTOSToolStripMenuItem
        '
        Me.PRODUTOSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PRODUTOSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastrarProdutoToolStripMenuItem, Me.EstoqueToolStripMenuItem, Me.ToolStripMenuItem1})
        Me.PRODUTOSToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PRODUTOSToolStripMenuItem.Name = "PRODUTOSToolStripMenuItem"
        Me.PRODUTOSToolStripMenuItem.Size = New System.Drawing.Size(111, 21)
        Me.PRODUTOSToolStripMenuItem.Text = "PRODUTOS"
        '
        'CadastrarProdutoToolStripMenuItem
        '
        Me.CadastrarProdutoToolStripMenuItem.Name = "CadastrarProdutoToolStripMenuItem"
        Me.CadastrarProdutoToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.CadastrarProdutoToolStripMenuItem.Text = "➕ Cadastrar Produto"
        '
        'EstoqueToolStripMenuItem
        '
        Me.EstoqueToolStripMenuItem.Name = "EstoqueToolStripMenuItem"
        Me.EstoqueToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.EstoqueToolStripMenuItem.Text = "📦 Estoque"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(210, 22)
        Me.ToolStripMenuItem1.Text = "🌱 Cadastrar Descarte"
        '
        'CLIENTESToolStripMenuItem
        '
        Me.CLIENTESToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.CLIENTESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastrarClienteToolStripMenuItem})
        Me.CLIENTESToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CLIENTESToolStripMenuItem.Name = "CLIENTESToolStripMenuItem"
        Me.CLIENTESToolStripMenuItem.Size = New System.Drawing.Size(111, 21)
        Me.CLIENTESToolStripMenuItem.Text = "FUNCIONÁRIOS"
        '
        'CadastrarClienteToolStripMenuItem
        '
        Me.CadastrarClienteToolStripMenuItem.Name = "CadastrarClienteToolStripMenuItem"
        Me.CadastrarClienteToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.CadastrarClienteToolStripMenuItem.Text = "👥 Cadastrar Funcionário"
        '
        'RELATÓRIOSToolStripMenuItem
        '
        Me.RELATÓRIOSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RELATÓRIOSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GerarRelatóriosToolStripMenuItem})
        Me.RELATÓRIOSToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RELATÓRIOSToolStripMenuItem.Name = "RELATÓRIOSToolStripMenuItem"
        Me.RELATÓRIOSToolStripMenuItem.Size = New System.Drawing.Size(111, 21)
        Me.RELATÓRIOSToolStripMenuItem.Text = "RELATÓRIOS"
        '
        'GerarRelatóriosToolStripMenuItem
        '
        Me.GerarRelatóriosToolStripMenuItem.Name = "GerarRelatóriosToolStripMenuItem"
        Me.GerarRelatóriosToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.GerarRelatóriosToolStripMenuItem.Text = "📄 Gerar Relatórios"
        '
        'LOGOUTToolStripMenuItem
        '
        Me.LOGOUTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LOGOUTToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LOGOUTToolStripMenuItem.Name = "LOGOUTToolStripMenuItem"
        Me.LOGOUTToolStripMenuItem.Size = New System.Drawing.Size(111, 21)
        Me.LOGOUTToolStripMenuItem.Text = "LOGOUT"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox8)
        Me.Panel1.Controls.Add(Me.MenuStrip2)
        Me.Panel1.Location = New System.Drawing.Point(37, -2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(194, 231)
        Me.Panel1.TabIndex = 6
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.hortinha.My.Resources.Resources.Design_sem_nome__2_
        Me.PictureBox8.Location = New System.Drawing.Point(6, 12)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(185, 50)
        Me.PictureBox8.TabIndex = 16
        Me.PictureBox8.TabStop = False
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.PictureBox10)
        Me.Panel13.Location = New System.Drawing.Point(313, 12)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(462, 48)
        Me.Panel13.TabIndex = 17
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.hortinha.My.Resources.Resources.ATENÇÃO_Verificação_de_Validade_Necessária__1_
        Me.PictureBox10.Location = New System.Drawing.Point(-2, -2)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(464, 50)
        Me.PictureBox10.TabIndex = 0
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.hortinha.My.Resources.Resources.Design_sem_nome__3_
        Me.PictureBox9.Location = New System.Drawing.Point(37, -5)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(201, 40)
        Me.PictureBox9.TabIndex = 16
        Me.PictureBox9.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.hortinha.My.Resources.Resources.Black_and_White_Geometric_Nexus_IT_Logo
        Me.PictureBox7.Location = New System.Drawing.Point(-7, 258)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(239, 215)
        Me.PictureBox7.TabIndex = 15
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.hortinha.My.Resources.Resources.Oxygen_Icons_org_Oxygen_Apps_clock_16
        Me.PictureBox6.Location = New System.Drawing.Point(835, 125)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(21, 21)
        Me.PictureBox6.TabIndex = 3
        Me.PictureBox6.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.hortinha.My.Resources.Resources.Captura_de_tela_2025_11_15_132853
        Me.PictureBox2.Location = New System.Drawing.Point(238, 70)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(352, 38)
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'menu
        '
        Me.menu.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.menu.Image = Global.hortinha.My.Resources.Resources.Ionic_Ionicons_Menu_32
        Me.menu.Location = New System.Drawing.Point(5, -2)
        Me.menu.Name = "menu"
        Me.menu.Size = New System.Drawing.Size(33, 34)
        Me.menu.TabIndex = 4
        Me.menu.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.hortinha.My.Resources.Resources.Bem_vindo__1_
        Me.PictureBox1.Location = New System.Drawing.Point(-7, -8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(894, 512)
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(881, 501)
        Me.Controls.Add(Me.Panel13)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.menu)
        Me.Controls.Add(Me.PictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HortiControl"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel13.ResumeLayout(False)
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.menu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents menu As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents barra_produtos As ProgressBar
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents lbl_produtos As Label
    Friend WithEvents lbl_categorias_baixoestoque As Label
    Friend WithEvents lbl_produtos_baixoestoque As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents dias_expirantes As Label
    Friend WithEvents lbl_categorias_expirantes As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lbl_produtos_expirantes As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lbl_valorestoque As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lbl_baixoestoque As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lbl_expirantes As Label
    Friend WithEvents lbl_organicos As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents lbl_ervas As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents lbl_legumes As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents lbl_frutas As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents DASHBOARDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VisãoGeralToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VENDASToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NovaVendaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PRODUTOSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CadastrarProdutoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EstoqueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CLIENTESToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CadastrarClienteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RELATÓRIOSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GerarRelatóriosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel1 As Panel
    Friend WithEvents LOGOUTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents qtde_baixoestoque As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Panel13 As Panel
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
End Class
