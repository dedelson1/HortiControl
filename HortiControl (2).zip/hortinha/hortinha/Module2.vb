﻿Module Module2
    Public Sub AtualizarDashboardGlobal()
        For Each form As Form In Application.OpenForms
            If TypeOf form Is Form2 Then
                DirectCast(form, Form2).atualizarDashboard()
                Exit For
            End If
        Next
    End Sub
End Module
