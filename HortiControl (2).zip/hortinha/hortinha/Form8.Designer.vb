﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form8))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmb_status = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.box_imagem = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_cpf = New System.Windows.Forms.MaskedTextBox()
        Me.vizu_csenha = New System.Windows.Forms.CheckBox()
        Me.vizu_senha = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmb_nivel = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.data_nasc = New System.Windows.Forms.DateTimePicker()
        Me.txt_csenha = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_senha = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_email = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_nome = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cpf = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.nome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.data_nascimento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.nivel_de_acesso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.estado_da_conta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.editar = New System.Windows.Forms.DataGridViewImageColumn()
        Me.excluir = New System.Windows.Forms.DataGridViewImageColumn()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btn_gravar = New System.Windows.Forms.Button()
        Me.DataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn2 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.box_imagem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 100)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(687, 265)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.cmb_status)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.txt_cpf)
        Me.TabPage1.Controls.Add(Me.vizu_csenha)
        Me.TabPage1.Controls.Add(Me.vizu_senha)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.cmb_nivel)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.data_nasc)
        Me.TabPage1.Controls.Add(Me.txt_csenha)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.txt_senha)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.txt_email)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.txt_nome)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(679, 239)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Sistema de Cadastro"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(500, 190)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(83, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Status da Conta"
        '
        'cmb_status
        '
        Me.cmb_status.FormattingEnabled = True
        Me.cmb_status.Items.AddRange(New Object() {"ATIVA", "INATIVA"})
        Me.cmb_status.Location = New System.Drawing.Point(503, 206)
        Me.cmb_status.Name = "cmb_status"
        Me.cmb_status.Size = New System.Drawing.Size(157, 21)
        Me.cmb_status.TabIndex = 16
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.box_imagem)
        Me.Panel1.Location = New System.Drawing.Point(514, 17)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(131, 170)
        Me.Panel1.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 13)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Foto de Perfil"
        '
        'box_imagem
        '
        Me.box_imagem.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.box_imagem.Location = New System.Drawing.Point(14, 29)
        Me.box_imagem.Name = "box_imagem"
        Me.box_imagem.Size = New System.Drawing.Size(104, 132)
        Me.box_imagem.TabIndex = 0
        Me.box_imagem.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(271, 68)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "CPF do Funcionário"
        '
        'txt_cpf
        '
        Me.txt_cpf.Location = New System.Drawing.Point(274, 84)
        Me.txt_cpf.Mask = "999,999,999-99"
        Me.txt_cpf.Name = "txt_cpf"
        Me.txt_cpf.Size = New System.Drawing.Size(195, 20)
        Me.txt_cpf.TabIndex = 14
        '
        'vizu_csenha
        '
        Me.vizu_csenha.AutoSize = True
        Me.vizu_csenha.Location = New System.Drawing.Point(274, 163)
        Me.vizu_csenha.Name = "vizu_csenha"
        Me.vizu_csenha.Size = New System.Drawing.Size(104, 17)
        Me.vizu_csenha.TabIndex = 13
        Me.vizu_csenha.Text = "Visualizar Senha"
        Me.vizu_csenha.UseVisualStyleBackColor = True
        '
        'vizu_senha
        '
        Me.vizu_senha.AutoSize = True
        Me.vizu_senha.Location = New System.Drawing.Point(22, 162)
        Me.vizu_senha.Name = "vizu_senha"
        Me.vizu_senha.Size = New System.Drawing.Size(104, 17)
        Me.vizu_senha.TabIndex = 12
        Me.vizu_senha.Text = "Visualizar Senha"
        Me.vizu_senha.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(271, 190)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Nível de Acesso"
        '
        'cmb_nivel
        '
        Me.cmb_nivel.FormattingEnabled = True
        Me.cmb_nivel.Items.AddRange(New Object() {"Gestor", "Vendedor", "Estoquista", "Qualidade", "Financeiro", "Compra/Vendas"})
        Me.cmb_nivel.Location = New System.Drawing.Point(274, 206)
        Me.cmb_nivel.Name = "cmb_nivel"
        Me.cmb_nivel.Size = New System.Drawing.Size(195, 21)
        Me.cmb_nivel.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(19, 191)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Data de Nascimento"
        '
        'data_nasc
        '
        Me.data_nasc.Location = New System.Drawing.Point(22, 207)
        Me.data_nasc.Name = "data_nasc"
        Me.data_nasc.Size = New System.Drawing.Size(195, 20)
        Me.data_nasc.TabIndex = 8
        '
        'txt_csenha
        '
        Me.txt_csenha.Location = New System.Drawing.Point(274, 136)
        Me.txt_csenha.Name = "txt_csenha"
        Me.txt_csenha.Size = New System.Drawing.Size(195, 20)
        Me.txt_csenha.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(271, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Confirmar Senha*"
        '
        'txt_senha
        '
        Me.txt_senha.Location = New System.Drawing.Point(22, 136)
        Me.txt_senha.Name = "txt_senha"
        Me.txt_senha.Size = New System.Drawing.Size(195, 20)
        Me.txt_senha.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(19, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Senha*"
        '
        'txt_email
        '
        Me.txt_email.Location = New System.Drawing.Point(22, 84)
        Me.txt_email.Name = "txt_email"
        Me.txt_email.Size = New System.Drawing.Size(195, 20)
        Me.txt_email.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Email do Funcionário"
        '
        'txt_nome
        '
        Me.txt_nome.Location = New System.Drawing.Point(22, 33)
        Me.txt_nome.Name = "txt_nome"
        Me.txt_nome.Size = New System.Drawing.Size(447, 20)
        Me.txt_nome.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nome do Funcionário"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.DataGridView1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(679, 239)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Funcionários Cadastrados"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.cpf, Me.nome, Me.email, Me.data_nascimento, Me.nivel_de_acesso, Me.estado_da_conta, Me.editar, Me.excluir})
        Me.DataGridView1.Location = New System.Drawing.Point(6, 6)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(668, 230)
        Me.DataGridView1.TabIndex = 0
        '
        'id
        '
        Me.id.HeaderText = "ID"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        '
        'cpf
        '
        Me.cpf.HeaderText = "CPF"
        Me.cpf.Name = "cpf"
        Me.cpf.ReadOnly = True
        '
        'nome
        '
        Me.nome.HeaderText = "NOME"
        Me.nome.Name = "nome"
        Me.nome.ReadOnly = True
        '
        'email
        '
        Me.email.HeaderText = "EMAIL"
        Me.email.Name = "email"
        Me.email.ReadOnly = True
        '
        'data_nascimento
        '
        Me.data_nascimento.HeaderText = "DATA DE NASCIMENTO"
        Me.data_nascimento.Name = "data_nascimento"
        Me.data_nascimento.ReadOnly = True
        '
        'nivel_de_acesso
        '
        Me.nivel_de_acesso.HeaderText = "NÍVEL DE ACESSO"
        Me.nivel_de_acesso.Name = "nivel_de_acesso"
        Me.nivel_de_acesso.ReadOnly = True
        '
        'estado_da_conta
        '
        Me.estado_da_conta.HeaderText = "ESTADO DA CONTA"
        Me.estado_da_conta.Name = "estado_da_conta"
        Me.estado_da_conta.ReadOnly = True
        '
        'editar
        '
        Me.editar.HeaderText = "EDITAR"
        Me.editar.Image = Global.hortinha.My.Resources.Resources.Oxygen_Icons_org_Oxygen_Actions_document_edit_24
        Me.editar.Name = "editar"
        Me.editar.ReadOnly = True
        '
        'excluir
        '
        Me.excluir.HeaderText = "EXCLUIR"
        Me.excluir.Image = Global.hortinha.My.Resources.Resources.Iconshock_Vista_General_Trash_24
        Me.excluir.Name = "excluir"
        Me.excluir.ReadOnly = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 371)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(331, 35)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "⬅ Voltar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btn_gravar
        '
        Me.btn_gravar.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.btn_gravar.ForeColor = System.Drawing.SystemColors.Control
        Me.btn_gravar.Location = New System.Drawing.Point(364, 371)
        Me.btn_gravar.Name = "btn_gravar"
        Me.btn_gravar.Size = New System.Drawing.Size(331, 35)
        Me.btn_gravar.TabIndex = 3
        Me.btn_gravar.Text = "Gravar"
        Me.btn_gravar.UseVisualStyleBackColor = False
        '
        'DataGridViewImageColumn1
        '
        Me.DataGridViewImageColumn1.HeaderText = "EDITAR"
        Me.DataGridViewImageColumn1.Image = Global.hortinha.My.Resources.Resources.Oxygen_Icons_org_Oxygen_Actions_document_edit_24
        Me.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1"
        Me.DataGridViewImageColumn1.ReadOnly = True
        '
        'DataGridViewImageColumn2
        '
        Me.DataGridViewImageColumn2.HeaderText = "EXCLUIR"
        Me.DataGridViewImageColumn2.Image = Global.hortinha.My.Resources.Resources.Iconshock_Vista_General_Trash_24
        Me.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2"
        Me.DataGridViewImageColumn2.ReadOnly = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.hortinha.My.Resources.Resources.CADASTRO_DE_PRODUTOS__2_
        Me.PictureBox1.Location = New System.Drawing.Point(-1, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(714, 95)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Form8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(711, 417)
        Me.Controls.Add(Me.btn_gravar)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form8"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HortiControl"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.box_imagem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents box_imagem As PictureBox
    Friend WithEvents txt_email As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_nome As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents vizu_csenha As CheckBox
    Friend WithEvents vizu_senha As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents cmb_nivel As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents data_nasc As DateTimePicker
    Friend WithEvents txt_csenha As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txt_senha As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Button1 As Button
    Friend WithEvents btn_gravar As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents DataGridViewImageColumn1 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn2 As DataGridViewImageColumn
    Friend WithEvents id As DataGridViewTextBoxColumn
    Friend WithEvents cpf As DataGridViewTextBoxColumn
    Friend WithEvents nome As DataGridViewTextBoxColumn
    Friend WithEvents email As DataGridViewTextBoxColumn
    Friend WithEvents data_nascimento As DataGridViewTextBoxColumn
    Friend WithEvents nivel_de_acesso As DataGridViewTextBoxColumn
    Friend WithEvents estado_da_conta As DataGridViewTextBoxColumn
    Friend WithEvents editar As DataGridViewImageColumn
    Friend WithEvents excluir As DataGridViewImageColumn
    Friend WithEvents Label9 As Label
    Friend WithEvents cmb_status As ComboBox
End Class
