﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txt_descricao = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.data_atual = New System.Windows.Forms.DateTimePicker()
        Me.data_vencimento = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btn_outros = New System.Windows.Forms.Button()
        Me.btn_qualidade = New System.Windows.Forms.Button()
        Me.btn_praga = New System.Windows.Forms.Button()
        Me.btn_danificado = New System.Windows.Forms.Button()
        Me.btn_deteriorado = New System.Windows.Forms.Button()
        Me.btn_vencido = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.quantidade_descartada = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nome_produto = New System.Windows.Forms.TextBox()
        Me.label = New System.Windows.Forms.Label()
        Me.quantidade_estoque = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.unidade = New System.Windows.Forms.ComboBox()
        Me.categoria = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.id_produto = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btn_cancel = New System.Windows.Forms.Button()
        Me.cadastrar_venda = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.txt_descricao)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.data_atual)
        Me.Panel1.Controls.Add(Me.data_vencimento)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.btn_outros)
        Me.Panel1.Controls.Add(Me.btn_qualidade)
        Me.Panel1.Controls.Add(Me.btn_praga)
        Me.Panel1.Controls.Add(Me.btn_danificado)
        Me.Panel1.Controls.Add(Me.btn_deteriorado)
        Me.Panel1.Controls.Add(Me.btn_vencido)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.quantidade_descartada)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.nome_produto)
        Me.Panel1.Controls.Add(Me.label)
        Me.Panel1.Controls.Add(Me.quantidade_estoque)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.unidade)
        Me.Panel1.Controls.Add(Me.categoria)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.id_produto)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(69, 107)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(726, 289)
        Me.Panel1.TabIndex = 1
        '
        'txt_descricao
        '
        Me.txt_descricao.Location = New System.Drawing.Point(34, 245)
        Me.txt_descricao.Name = "txt_descricao"
        Me.txt_descricao.Size = New System.Drawing.Size(385, 20)
        Me.txt_descricao.TabIndex = 48
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(31, 229)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(116, 13)
        Me.Label9.TabIndex = 47
        Me.Label9.Text = "Descrição do Descarte"
        '
        'data_atual
        '
        Me.data_atual.Location = New System.Drawing.Point(258, 198)
        Me.data_atual.Name = "data_atual"
        Me.data_atual.Size = New System.Drawing.Size(161, 20)
        Me.data_atual.TabIndex = 46
        '
        'data_vencimento
        '
        Me.data_vencimento.Location = New System.Drawing.Point(34, 198)
        Me.data_vencimento.Name = "data_vencimento"
        Me.data_vencimento.Size = New System.Drawing.Size(173, 20)
        Me.data_vencimento.TabIndex = 45
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(255, 182)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(91, 13)
        Me.Label8.TabIndex = 44
        Me.Label8.Text = "Data de Descarte"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(31, 182)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 13)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "Data de Vencimento"
        '
        'btn_outros
        '
        Me.btn_outros.Location = New System.Drawing.Point(595, 208)
        Me.btn_outros.Name = "btn_outros"
        Me.btn_outros.Size = New System.Drawing.Size(103, 57)
        Me.btn_outros.TabIndex = 42
        Me.btn_outros.Text = "📝 Outros"
        Me.btn_outros.UseVisualStyleBackColor = True
        '
        'btn_qualidade
        '
        Me.btn_qualidade.Location = New System.Drawing.Point(479, 59)
        Me.btn_qualidade.Name = "btn_qualidade"
        Me.btn_qualidade.Size = New System.Drawing.Size(103, 57)
        Me.btn_qualidade.TabIndex = 41
        Me.btn_qualidade.Text = "⚠️ Qualidade"
        Me.btn_qualidade.UseVisualStyleBackColor = True
        '
        'btn_praga
        '
        Me.btn_praga.Location = New System.Drawing.Point(479, 134)
        Me.btn_praga.Name = "btn_praga"
        Me.btn_praga.Size = New System.Drawing.Size(103, 59)
        Me.btn_praga.TabIndex = 40
        Me.btn_praga.Text = "🐛 Praga"
        Me.btn_praga.UseVisualStyleBackColor = True
        '
        'btn_danificado
        '
        Me.btn_danificado.Location = New System.Drawing.Point(595, 134)
        Me.btn_danificado.Name = "btn_danificado"
        Me.btn_danificado.Size = New System.Drawing.Size(103, 57)
        Me.btn_danificado.TabIndex = 39
        Me.btn_danificado.Text = "💥 Danificado"
        Me.btn_danificado.UseVisualStyleBackColor = True
        '
        'btn_deteriorado
        '
        Me.btn_deteriorado.Location = New System.Drawing.Point(595, 59)
        Me.btn_deteriorado.Name = "btn_deteriorado"
        Me.btn_deteriorado.Size = New System.Drawing.Size(103, 57)
        Me.btn_deteriorado.TabIndex = 38
        Me.btn_deteriorado.Text = "🍁 Deteriorado"
        Me.btn_deteriorado.UseVisualStyleBackColor = True
        '
        'btn_vencido
        '
        Me.btn_vencido.Location = New System.Drawing.Point(479, 208)
        Me.btn_vencido.Name = "btn_vencido"
        Me.btn_vencido.Size = New System.Drawing.Size(103, 57)
        Me.btn_vencido.TabIndex = 37
        Me.btn_vencido.Text = "⏰ Vencido"
        Me.btn_vencido.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(476, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Motivo"
        '
        'quantidade_descartada
        '
        Me.quantidade_descartada.Location = New System.Drawing.Point(258, 154)
        Me.quantidade_descartada.Name = "quantidade_descartada"
        Me.quantidade_descartada.Size = New System.Drawing.Size(161, 20)
        Me.quantidade_descartada.TabIndex = 35
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(255, 138)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(146, 13)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Quantidade a ser Descartada"
        '
        'nome_produto
        '
        Me.nome_produto.Location = New System.Drawing.Point(34, 73)
        Me.nome_produto.Name = "nome_produto"
        Me.nome_produto.Size = New System.Drawing.Size(385, 20)
        Me.nome_produto.TabIndex = 33
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Location = New System.Drawing.Point(31, 57)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(90, 13)
        Me.label.TabIndex = 32
        Me.label.Text = "Nome do Produto"
        '
        'quantidade_estoque
        '
        Me.quantidade_estoque.Location = New System.Drawing.Point(34, 154)
        Me.quantidade_estoque.Name = "quantidade_estoque"
        Me.quantidade_estoque.Size = New System.Drawing.Size(173, 20)
        Me.quantidade_estoque.TabIndex = 31
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(31, 138)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 13)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Quantidade em Estoque"
        '
        'unidade
        '
        Me.unidade.FormattingEnabled = True
        Me.unidade.Items.AddRange(New Object() {"Quilograma (kg)", "Grama (g)", "Miligrama (mg)", "Unidade (un)", "Maço", "Caixa"})
        Me.unidade.Location = New System.Drawing.Point(258, 111)
        Me.unidade.Name = "unidade"
        Me.unidade.Size = New System.Drawing.Size(161, 21)
        Me.unidade.TabIndex = 29
        '
        'categoria
        '
        Me.categoria.FormattingEnabled = True
        Me.categoria.Items.AddRange(New Object() {"Frutas", "Legumes", "Ervas", "Orgânicos"})
        Me.categoria.Location = New System.Drawing.Point(34, 111)
        Me.categoria.Name = "categoria"
        Me.categoria.Size = New System.Drawing.Size(173, 21)
        Me.categoria.TabIndex = 28
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(255, 96)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Unidade"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 95)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Categoria"
        '
        'id_produto
        '
        Me.id_produto.Location = New System.Drawing.Point(34, 36)
        Me.id_produto.Name = "id_produto"
        Me.id_produto.Size = New System.Drawing.Size(385, 20)
        Me.id_produto.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "ID do Produto"
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(69, 402)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(356, 36)
        Me.btn_cancel.TabIndex = 22
        Me.btn_cancel.Text = "Cancelar"
        Me.btn_cancel.UseVisualStyleBackColor = True
        '
        'cadastrar_venda
        '
        Me.cadastrar_venda.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.cadastrar_venda.ForeColor = System.Drawing.SystemColors.Control
        Me.cadastrar_venda.Location = New System.Drawing.Point(431, 402)
        Me.cadastrar_venda.Name = "cadastrar_venda"
        Me.cadastrar_venda.Size = New System.Drawing.Size(364, 36)
        Me.cadastrar_venda.TabIndex = 23
        Me.cadastrar_venda.Text = "Cadastrar Descarte"
        Me.cadastrar_venda.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.hortinha.My.Resources.Resources.CADASTRO_DE_PRODUTOS__1_
        Me.PictureBox1.Location = New System.Drawing.Point(0, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(867, 104)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(863, 450)
        Me.Controls.Add(Me.cadastrar_venda)
        Me.Controls.Add(Me.btn_cancel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form6"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HortiControl"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents quantidade_descartada As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents nome_produto As TextBox
    Friend WithEvents label As Label
    Friend WithEvents quantidade_estoque As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents unidade As ComboBox
    Friend WithEvents categoria As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents id_produto As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btn_outros As Button
    Friend WithEvents btn_qualidade As Button
    Friend WithEvents btn_praga As Button
    Friend WithEvents btn_danificado As Button
    Friend WithEvents btn_deteriorado As Button
    Friend WithEvents btn_vencido As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_descricao As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents data_atual As DateTimePicker
    Friend WithEvents data_vencimento As DateTimePicker
    Friend WithEvents btn_cancel As Button
    Friend WithEvents cadastrar_venda As Button
End Class
